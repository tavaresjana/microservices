package com.ibmshop.backendsecurityapi.service;

import java.util.List;

import org.springframework.security.core.GrantedAuthority;

public interface JwtProvider {
	String gerarToken(String email, List<? extends GrantedAuthority> Roles);

	void validarToken(String token);
	
}
