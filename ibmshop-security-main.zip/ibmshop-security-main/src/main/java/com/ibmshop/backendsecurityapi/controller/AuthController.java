package com.ibmshop.backendsecurityapi.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ibmshop.backendsecurityapi.dto.LoginDto;
import com.ibmshop.backendsecurityapi.dto.UsuarioCredentialDto;
import com.ibmshop.backendsecurityapi.dto.UsuarioCredentialRegistroDto;
import com.ibmshop.backendsecurityapi.service.AuthService;
import com.ibmshop.backendsecurityapi.service.JwtProvider;
import com.ibmshop.backendsecurityapi.service.JwtProviderImpl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
@RestController
@RequestMapping("/auth")
public class AuthController {
	
	private final AuthService service;
	
	private final JwtProvider jwtProvider;

	@PostMapping("/admin")
	public ResponseEntity<UsuarioCredentialDto> cadastrarAdmin(@RequestBody UsuarioCredentialRegistroDto dto) {
		log.info("Criando admin...");
		UsuarioCredentialDto admin = service.cadastrarAdmin(dto);
		log.info("Admin criado com sucesso");
		return ResponseEntity.ok(admin);
	}

	@PostMapping("/usuario")
	public ResponseEntity<UsuarioCredentialDto> cadastrarUsuario(@RequestBody UsuarioCredentialRegistroDto dto) {
		log.info("Criando usuário...");
		UsuarioCredentialDto usuario = service.cadastrarUsuario(dto);
		log.info("Usuário criado com sucesso");
		return ResponseEntity.ok(usuario);
	}

	@PostMapping("/login")
	public ResponseEntity<String> login(@RequestBody LoginDto dto) {
		return ResponseEntity.ok(service.login(dto));
	}

	@GetMapping("/validar")
	public String validarToken(@RequestParam("token") String token) {
		jwtProvider.validarToken(token);
		return "Token válido";
	}
}
