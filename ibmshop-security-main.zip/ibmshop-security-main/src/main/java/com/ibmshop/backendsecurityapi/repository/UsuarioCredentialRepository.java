package com.ibmshop.backendsecurityapi.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ibmshop.backendsecurityapi.entidades.UsuarioCredential;

@Repository
public interface UsuarioCredentialRepository extends JpaRepository<UsuarioCredential, Long>{
	Optional<UsuarioCredential> findByEmail(String email);
}
