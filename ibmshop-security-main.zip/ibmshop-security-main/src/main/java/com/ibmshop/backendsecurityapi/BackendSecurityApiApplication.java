package com.ibmshop.backendsecurityapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

//@ComponentScan({"com.ibmshop.request"})
@EnableDiscoveryClient
@SpringBootApplication

//@SpringBootApplication(scanBasePackages={"com.ibmshop.security.service.AuthServiceImpl", "com.ibmshop.security.service.JwtProviderImpl"})
public class BackendSecurityApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendSecurityApiApplication.class, args);
	}
	
/*	@Bean
	public javax.sql.DataSource datasource() {
		return DataSourceBuilder.create().driverClassName("com.mysql.cj.jdbc.Driver")
				.url("jdbc:mysql://127.0.0.1:3306/db_security").username("root").password("root").build();
	}*/
}
