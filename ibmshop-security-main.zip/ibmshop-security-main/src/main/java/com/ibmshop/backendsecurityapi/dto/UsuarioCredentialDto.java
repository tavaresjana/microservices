package com.ibmshop.backendsecurityapi.dto;


import com.ibmshop.backendsecurityapi.entidades.Role;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UsuarioCredentialDto {

	String email;
	String Senha;

	Role role;

	boolean ativo;
}

