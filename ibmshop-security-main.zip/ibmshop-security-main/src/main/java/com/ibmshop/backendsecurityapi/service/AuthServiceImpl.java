package com.ibmshop.backendsecurityapi.service;

import java.util.List;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.ibmshop.backendsecurityapi.dto.LoginDto;
import com.ibmshop.backendsecurityapi.dto.UsuarioCredentialDto;
import com.ibmshop.backendsecurityapi.dto.UsuarioCredentialRegistroDto;
import com.ibmshop.backendsecurityapi.entidades.Role;
import com.ibmshop.backendsecurityapi.entidades.UsuarioCredential;
import com.ibmshop.backendsecurityapi.mapper.UsuarioCredentialMapper;
import com.ibmshop.backendsecurityapi.repository.UsuarioCredentialRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
@Service
public class AuthServiceImpl implements AuthService {
	private final UsuarioCredentialRepository repository;
	private final UsuarioCredentialMapper mapper;
	private final AuthenticationManager authenticationManager;
	private final PasswordEncoder passwordEncoder;
	private final JwtProvider jwtProvider;

	@Override
	@Transactional
	public UsuarioCredentialDto cadastrarAdmin(UsuarioCredentialRegistroDto dto) {
		UsuarioCredential admin = setarSenha(dto);
		admin.setRole(Role.ADMIN);
		admin.setAtivo(true);
		return mapper.entidadeParaUsuarioCredentialDto(repository.save(admin));
	}

	@Override
	@Transactional
	public UsuarioCredentialDto cadastrarUsuario(UsuarioCredentialRegistroDto dto) {
		UsuarioCredential usuario = setarSenha(dto);
		usuario.setRole(Role.USER);
		usuario.setAtivo(true);
		return mapper.entidadeParaUsuarioCredentialDto(repository.save(usuario));
	}

	private UsuarioCredential setarSenha(UsuarioCredentialRegistroDto dto) {
		UsuarioCredential usuario = mapper.registroDtoParaUsuarioCredential(dto);
		usuario.setSenha(passwordEncoder.encode(dto.getSenha()));
		return usuario;
	}

	@Override
	public String login(LoginDto dto) {
		try {
			Authentication authenticate = authenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken(dto.getEmail(), dto.getSenha()));
			if (authenticate.isAuthenticated())
				return jwtProvider.gerarToken(authenticate.getName(),
						(List<? extends GrantedAuthority>) authenticate.getAuthorities());
			else
				throw new RuntimeException("Erro ao gerar token");
		} catch (AuthenticationException e) {
			log.info(e.getMessage());
			return null;
		}
	}
}
