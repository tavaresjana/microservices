package com.ibmshop.backendsecurityapi.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.ibmshop.backendsecurityapi.config.CustomUserDetails;
import com.ibmshop.backendsecurityapi.entidades.UsuarioCredential;
import com.ibmshop.backendsecurityapi.repository.UsuarioCredentialRepository;

@Component
public class CustomUserDetailsService implements UserDetailsService{
	
	@Autowired
	private UsuarioCredentialRepository repository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<UsuarioCredential> credential = repository.findByEmail(username);
		return credential.map(CustomUserDetails::new)
				.orElseThrow(() -> new UsernameNotFoundException("user not found with name :" + username));
	}
}
