package com.ibmshop.backendsecurityapi.service;

import com.ibmshop.backendsecurityapi.dto.LoginDto;
import com.ibmshop.backendsecurityapi.dto.UsuarioCredentialDto;
import com.ibmshop.backendsecurityapi.dto.UsuarioCredentialRegistroDto;

public interface AuthService {

	String login(LoginDto dto);

	UsuarioCredentialDto cadastrarUsuario(UsuarioCredentialRegistroDto dto);

	UsuarioCredentialDto cadastrarAdmin(UsuarioCredentialRegistroDto dto);

}
