package com.ibmshop.backendsecurityapi.mapper;

import org.mapstruct.Mapper;

import com.ibmshop.backendsecurityapi.dto.UsuarioCredentialDto;
import com.ibmshop.backendsecurityapi.dto.UsuarioCredentialRegistroDto;
import com.ibmshop.backendsecurityapi.entidades.UsuarioCredential;

@Mapper(componentModel = "spring")
public interface UsuarioCredentialMapper {
	
    UsuarioCredentialDto entidadeParaUsuarioCredentialDto(UsuarioCredential userCredential);

    UsuarioCredential registroDtoParaUsuarioCredential(UsuarioCredentialRegistroDto dto);
}
