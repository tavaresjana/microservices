package com.ibmshop.discountapi.domain.usecase;

import org.springframework.stereotype.Component;

import com.ibmshop.discountapi.domain.gateway.CupomGateway;
import com.ibmshop.discountapi.domain.model.Cupom;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
public class FindByIdImpl implements FindById{

	private final CupomGateway cupomGateway;
	
	@Override
	public Cupom findById(Long id) {
		return cupomGateway.findByIdGateway(id);
	}
	

}
