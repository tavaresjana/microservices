package com.ibmshop.discountapi.domain.usecase;

public interface UpdateCupom {

}
