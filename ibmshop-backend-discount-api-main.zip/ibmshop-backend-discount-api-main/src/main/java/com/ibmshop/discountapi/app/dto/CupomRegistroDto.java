package com.ibmshop.discountapi.app.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CupomRegistroDto {

	private Long id;
	
	private String codigo;

	@Column(nullable = false)
	private BigDecimal percentual;

	@Column(nullable = true)
	private Integer qtdMinimaProdutos;

	@Column(nullable = true)
	private BigDecimal valorMinimoPedido;

	@Column(nullable = true)
	private BigDecimal descontoMaximo;

	@Column(nullable = false)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy", timezone = "GMT")
	private LocalDate dataCricao = LocalDate.now();

	@Column(nullable = false)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy", timezone = "GMT")
	private LocalDate dataExpiracao;

	@Column(nullable = false)
	private Boolean ativo;
}
