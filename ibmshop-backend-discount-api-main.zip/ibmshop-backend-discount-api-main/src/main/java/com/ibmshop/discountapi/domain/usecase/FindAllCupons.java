package com.ibmshop.discountapi.domain.usecase;

import java.util.List;

import com.ibmshop.discountapi.domain.model.Cupom;

public interface FindAllCupons {

	//List<Cupom> findAllCupons();
}
