package com.ibmshop.discountapi.infra.dataprovider;

import java.util.Optional;

import org.springframework.stereotype.Component;

import com.ibmshop.discountapi.domain.gateway.CupomGateway;
import com.ibmshop.discountapi.domain.model.Cupom;
import com.ibmshop.discountapi.infra.entity.CupomEntity;
import com.ibmshop.discountapi.infra.repository.CupomRepository;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
public class CupomDataProvider implements CupomGateway {

	private final CupomRepository cupomRepository;

	private final DataProviderMapper dataProviderMapper;

	@Override
	public Cupom saveCupomGateway(Cupom cupom) {
		CupomEntity cupomEntity = dataProviderMapper.cupomModelToCupomEntity(cupom);
		return dataProviderMapper.cupomEntityToCupomModel(cupomRepository.save(cupomEntity));
	}

	@Override
	public Cupom findByIdGateway(Long id) {
		Optional<CupomEntity> cupomEntityOptional = cupomRepository.findById(id);

		if (cupomEntityOptional.isPresent()) {
			return dataProviderMapper.cupomEntityToCupomModel(cupomEntityOptional.get());
		}

		return null;
	}
	
	@Override
    public Cupom findByCodigoGateway(String codigo) {
        Optional<CupomEntity> cupomEntityOptional = cupomRepository.findByCodigo(codigo);
        
        if (cupomEntityOptional.isPresent()) {
            return dataProviderMapper.cupomEntityToCupomModel(cupomEntityOptional.get());
        }
        
        return null; 
    }
//	@Override
//	public List<Cupom> findAllCuponsGateway() {
//		List<CupomEntity> cupomEntities = cupomRepository.findAllCupons();
//		List<Cupom> cupomModels = new ArrayList<>();
//
//		// mapeando cada cupomEntity para um objeto cupomModel, criando uma lista de
//		// CupomModel que será retornada pelo método findAllCupons.
//		for (CupomEntity cupomEntity : cupomEntities) {
//			Cupom cupomModel = dataProviderMapper.cupomEntityToCupomModel(cupomEntity);
//			cupomModels.add(cupomModel);
//		}
//
//		return cupomModels;
//	}

}