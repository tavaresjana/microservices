package com.ibmshop.discountapi.domain.usecase;

import java.util.List;

import com.ibmshop.discountapi.domain.gateway.CupomGateway;
import com.ibmshop.discountapi.domain.model.Cupom;

public class FindAllCuponsImpl  {

//	private final CupomGateway cupomGateway;
//
//	public FindAllCuponsImpl(CupomGateway cupomGateway) {
//		this.cupomGateway = cupomGateway;
//	}
//	
//	@Override
//	public List<Cupom> findAllCupons() {
//		return cupomGateway.findAllCuponsGateway();
//	}

	

}
