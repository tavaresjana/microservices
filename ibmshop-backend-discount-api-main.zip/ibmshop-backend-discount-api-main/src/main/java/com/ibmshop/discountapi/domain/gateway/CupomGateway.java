package com.ibmshop.discountapi.domain.gateway;

import com.ibmshop.discountapi.domain.model.Cupom;

public interface CupomGateway {
	
	Cupom saveCupomGateway(Cupom cupom);
	
	Cupom findByIdGateway(Long id);
	
	Cupom findByCodigoGateway(String codigo);
	
	//List<Cupom> findAllCuponsGateway();
}
