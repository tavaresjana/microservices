package com.ibmshop.discountapi.infra.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ibmshop.discountapi.infra.entity.CupomEntity;

@Repository
public interface CupomRepository extends JpaRepository<CupomEntity, Long> {

	@Query(value = "select u from CupomEntity u where u.codigo like %?1%")
	Optional<CupomEntity> findByCodigo(String codigo);
	

}