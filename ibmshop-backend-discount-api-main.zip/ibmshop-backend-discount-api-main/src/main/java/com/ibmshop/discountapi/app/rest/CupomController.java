package com.ibmshop.discountapi.app.rest;

import java.net.URI;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.ibmshop.discountapi.app.dto.CupomDto;
import com.ibmshop.discountapi.app.dto.CupomRegistroDto;
import com.ibmshop.discountapi.app.service.CupomManutencaoService;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/cupons")
public class CupomController {

	private final CupomManutencaoService manutencaoService;

	@PostMapping
	public ResponseEntity<CupomDto> save(@RequestBody CupomRegistroDto dto) {
		CupomDto cupom = manutencaoService.save(dto);
		URI uri = UriComponentsBuilder.fromPath("/cupons/{id}").buildAndExpand(cupom.getId()).toUri();
		return ResponseEntity.created(uri).body(cupom);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<CupomDto> findById(@PathVariable Long id) {
	    CupomDto cupom = manutencaoService.findById(id);
	   // URI uri = UriComponentsBuilder.fromPath("/cupons/{id}").buildAndExpand(cupom.getId()).toUri();
	    if (cupom != null) {
	        return ResponseEntity.ok(cupom);
	    } else {
	        return ResponseEntity.notFound().build();
	    }
	}
	
	@GetMapping("/codigo{codigo}")
	public ResponseEntity<CupomDto> findByCodigo(@PathVariable String codigo) {
	    CupomDto cupom = manutencaoService.findByCodigo(codigo);
	   // URI uri = UriComponentsBuilder.fromPath("/cupons/{id}").buildAndExpand(cupom.getId()).toUri();
	    if (cupom != null) {
	        return ResponseEntity.ok(cupom);
	    } else {
	        return ResponseEntity.notFound().build();
	    }
	}

}
