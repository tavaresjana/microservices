package com.ibmshop.discountapi.app.mapper;

import com.ibmshop.discountapi.app.dto.CupomDto;
import com.ibmshop.discountapi.app.dto.CupomRegistroDto;
import com.ibmshop.discountapi.domain.model.Cupom;

public interface CupomMapper {

	CupomDto cupomToDto(Cupom cupom);

	Cupom dtoToCupom(CupomRegistroDto dto);
	

}