package com.ibmshop.discountapi.infra.dataprovider;

import org.springframework.stereotype.Component;

import com.ibmshop.discountapi.domain.model.Cupom;
import com.ibmshop.discountapi.infra.entity.CupomEntity;

@Component
public class DataProviderMapper {

    public CupomEntity cupomModelToCupomEntity(Cupom cupom) {
        return new CupomEntity(cupom.getId(), cupom.getCodigo(), cupom.getPercentual(), cupom.getQtdMinimaProdutos(), cupom.getValorMinimoPedido(), cupom.getDescontoMaximo(), cupom.getDataCricao(), cupom.getDataExpiracao(), cupom.getAtivo());
    }

    public Cupom cupomEntityToCupomModel(CupomEntity cupomEntity) {
    	return new Cupom(cupomEntity.getId(), cupomEntity.getCodigo(), cupomEntity.getPercentual(), cupomEntity.getQtdMinimaProdutos(), cupomEntity.getValorMinimoPedido(), cupomEntity.getDescontoMaximo(), cupomEntity.getDataCricao(), cupomEntity.getDataExpiracao(), cupomEntity.getAtivo());
    }

}

