package com.ibmshop.discountapi.app.mapper;

import org.springframework.stereotype.Component;

import com.ibmshop.discountapi.app.dto.CupomDto;
import com.ibmshop.discountapi.app.dto.CupomRegistroDto;
import com.ibmshop.discountapi.domain.model.Cupom;

@Component
public class CupomMapperImpl implements CupomMapper {

	@Override
	public CupomDto cupomToDto(Cupom cupom) {
		return new CupomDto(cupom.getId(), cupom.getCodigo(), cupom.getPercentual(), cupom.getQtdMinimaProdutos(), cupom.getValorMinimoPedido(), cupom.getDescontoMaximo(), cupom.getDataCricao(), cupom.getDataExpiracao(), cupom.getAtivo());
	}

	@Override
	public Cupom dtoToCupom(CupomRegistroDto dto) {
		return new Cupom(dto.getId(), dto.getCodigo(), dto.getPercentual(), dto.getQtdMinimaProdutos(), dto.getValorMinimoPedido(), dto.getDescontoMaximo(), dto.getDataCricao(), dto.getDataExpiracao(), dto.getAtivo());
	}

}
