package com.ibmshop.discountapi.domain.usecase;

import com.ibmshop.discountapi.domain.model.Cupom;

public interface FindById {
	
	Cupom findById(Long id);
	
}
