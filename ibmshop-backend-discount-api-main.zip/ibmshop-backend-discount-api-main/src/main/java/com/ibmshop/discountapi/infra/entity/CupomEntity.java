package com.ibmshop.discountapi.infra.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tb_cupom")
@SequenceGenerator(name = "cupom", sequenceName = "sq_cupons", allocationSize = 1)
public class CupomEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cupom")
    private Long id;

    @Column(nullable = false, unique = true)
    private String codigo;
    
    @Column(nullable = false)
    private BigDecimal percentual;
    
    @Column(nullable = true)
    private Integer qtdMinimaProdutos;
    
    @Column(nullable = true)
    private BigDecimal valorMinimoPedido;
    
    @Column(nullable = true)
    private BigDecimal descontoMaximo;
    
    @Column(nullable = false)
    private LocalDate dataCricao;
    
    @Column(nullable = false)
    private LocalDate dataExpiracao;
    
    @Column(nullable = false)
    private Boolean ativo;

}
