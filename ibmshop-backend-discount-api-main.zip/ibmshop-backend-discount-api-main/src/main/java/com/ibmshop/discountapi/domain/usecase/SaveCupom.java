package com.ibmshop.discountapi.domain.usecase;

import com.ibmshop.discountapi.domain.model.Cupom;

public interface SaveCupom {

	Cupom save(Cupom cupom);
}
