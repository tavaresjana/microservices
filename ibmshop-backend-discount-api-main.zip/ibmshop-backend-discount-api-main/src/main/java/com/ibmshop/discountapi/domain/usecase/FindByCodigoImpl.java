package com.ibmshop.discountapi.domain.usecase;

import org.springframework.stereotype.Component;

import com.ibmshop.discountapi.domain.gateway.CupomGateway;
import com.ibmshop.discountapi.domain.model.Cupom;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
public class FindByCodigoImpl implements FindByCodigo {
	
	private final CupomGateway cupomGateway;
	
	public Cupom findByCodigo(String codigo) {
		return cupomGateway.findByCodigoGateway(codigo);
	}
}
