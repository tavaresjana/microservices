package com.ibmshop.discountapi.domain.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Cupom {
	
    private Long id;

    @Column(nullable = false, unique = true)
    private String codigo;
    
    @Column(nullable = false)
    private BigDecimal percentual;
    
    @Column(nullable = true)
    private Integer qtdMinimaProdutos;
    
    @Column(nullable = true)
    private BigDecimal valorMinimoPedido;
    
    @Column(nullable = true)
    private BigDecimal descontoMaximo;
    
    @Column(nullable = false)
    private LocalDate dataCricao;
    
    @Column(nullable = false)
    private LocalDate dataExpiracao;
    
    @Column(nullable = false)
    private Boolean ativo;
}
