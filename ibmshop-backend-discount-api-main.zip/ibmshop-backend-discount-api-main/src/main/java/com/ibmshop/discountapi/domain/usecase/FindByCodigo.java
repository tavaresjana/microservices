package com.ibmshop.discountapi.domain.usecase;

import com.ibmshop.discountapi.domain.model.Cupom;

public interface FindByCodigo {
	
	Cupom findByCodigo(String codigo);
}
