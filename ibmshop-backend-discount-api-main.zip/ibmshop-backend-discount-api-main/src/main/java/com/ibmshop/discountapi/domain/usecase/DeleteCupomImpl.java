package com.ibmshop.discountapi.domain.usecase;

public class DeleteCupomImpl implements DeleteCupom {

}
