package com.ibmshop.discountapi.domain.usecase;

public class UpdateCupomImpl implements UpdateCupom{

}
