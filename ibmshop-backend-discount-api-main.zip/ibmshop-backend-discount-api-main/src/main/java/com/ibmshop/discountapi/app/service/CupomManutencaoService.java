package com.ibmshop.discountapi.app.service;

import com.ibmshop.discountapi.app.dto.CupomDto;
import com.ibmshop.discountapi.app.dto.CupomRegistroDto;

public interface CupomManutencaoService {

	CupomDto save(CupomRegistroDto dto);
	
	CupomDto findById(Long id);
	
	CupomDto findByCodigo(String codigo);
	
	//List<CupomDto> findAllCupons();
}
