package com.ibmshop.discountapi.app.service;

import org.springframework.stereotype.Service;

import com.ibmshop.discountapi.app.dto.CupomDto;
import com.ibmshop.discountapi.app.dto.CupomRegistroDto;
import com.ibmshop.discountapi.app.mapper.CupomMapper;
import com.ibmshop.discountapi.domain.model.Cupom;
import com.ibmshop.discountapi.domain.usecase.FindByCodigo;
import com.ibmshop.discountapi.domain.usecase.FindById;
import com.ibmshop.discountapi.domain.usecase.SaveCupom;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
@Transactional
public class CupomManutencaoServiceImpl implements CupomManutencaoService {

	private final SaveCupom saveCupom;

	// private final FindAllCupons findAllCupons;

	private final FindById findById;
	
	private final FindByCodigo findByCodigo;

	private final CupomMapper cupomMapper;

	@Override
	public CupomDto save(CupomRegistroDto dto) {
		return cupomMapper.cupomToDto(saveCupom.save(cupomMapper.dtoToCupom(dto)));
	}
	
	 @Override
	    public CupomDto findById(Long id) {
		 CupomDto cupomr = cupomMapper.cupomToDto(findById.findById(id));
	      return cupomr; 
	    }

	@Override
	public CupomDto findByCodigo(String codigo) {
		Cupom cupom = findByCodigo.findByCodigo(codigo); 
        if (cupom != null) {
            return cupomMapper.cupomToDto(cupom);
        }
		return null; 
	}
	
//	 @Override
//	    public CupomDto findById(Long id) {
//	        Cupom cupom = findById.findById(id);  // Chame o método para encontrar o cupom pelo ID
//	        if (cupom != null) {
//	            return cupomMapper.cupomToDto(cupom);
//	        }
//			return null; 
//	    }

	
}

//	@Override
//	public List<CupomDto> findAllCupons() {
//		List<Cupom> cupons = findAllCupons.findAllCupons();
//		return cupons.stream().map(cupomMapper::cupomToDto).collect(Collectors.toList());
//	}

//	@Override
//	public List<CupomDto> findAllCupons() {
//		//List<Cupom> cupons = findAllCupons.findAllCupons();
//		//return cupons.stream().map(cupomMapper::cupomToDto).collect(Collectors.toList());
//	return null;
//	}
