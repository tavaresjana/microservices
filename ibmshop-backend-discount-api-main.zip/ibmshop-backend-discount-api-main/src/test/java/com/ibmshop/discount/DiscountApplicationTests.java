package com.ibmshop.discount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscountApplicationTests {

	@Test
	void contextLoads() {
	}

}
