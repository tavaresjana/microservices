package com.ibmshop.productsapi.resources.exceptions;

import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.ibmshop.productsapi.services.exceptions.UnprocessableEntityException;

import jakarta.persistence.EntityNotFoundException;

@RestControllerAdvice
public class ResourceExceptionHandler {

	
    
	@ExceptionHandler(EntityNotFoundException.class)
	public ResponseEntity<StandardError> ObjectNotFoundException(EntityNotFoundException e){
		HttpStatus status = HttpStatus.NOT_FOUND;
		StandardError error = new StandardError(Instant.now(), status.value(), e.getMessage());
		return ResponseEntity.status(status).body(error);
	}
	/*
	@ExceptionHandler(MissingServletRequestParameterException.class)
	public ResponseEntity<StandardError>MissingServletRequestParameterException(MissingServletRequestParameterException e) {
		StandardError error = new StandardError(System.currentTimeMillis(), HttpStatus.BAD_REQUEST.value(), e.getMessage());
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
	}
	*/
	 @ExceptionHandler(UnprocessableEntityException.class)
	    public ResponseEntity<StandardError> UnprocessableEntityException(UnprocessableEntityException e) {
	        HttpStatus status = HttpStatus.UNPROCESSABLE_ENTITY;
	        StandardError error = new StandardError(Instant.now(), status.value(), e.getMessage());
	        return ResponseEntity.status(status).body(error);
	    }
	 
	 @ExceptionHandler(MethodArgumentNotValidException.class)
	 public ResponseEntity<StandardError> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
	     List<String> errors = ex.getBindingResult()
	             .getFieldErrors()
	             .stream()
	             .map(FieldError::getDefaultMessage)
	             .collect(Collectors.toList());
	     String errorMessage = String.join(", ", errors);
	     HttpStatus status = HttpStatus.BAD_REQUEST;
	     StandardError error = new StandardError(Instant.now(), status.value(), errorMessage);
	     return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
	 }

}
