package com.ibmshop.productsapi.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ibmshop.productsapi.entities.Produto;

public interface ProdutoRepository extends JpaRepository<Produto, Long> {
	
	@Query(value = "select u from Produto u where u.nomeProduto like %?1%")
	List<Produto> findByNomeProduto(String nomeProduto);

	@Query(value = "select u from Produto u where u.sku = ?1")
	Optional<Produto> findBySku(int sku);


}
