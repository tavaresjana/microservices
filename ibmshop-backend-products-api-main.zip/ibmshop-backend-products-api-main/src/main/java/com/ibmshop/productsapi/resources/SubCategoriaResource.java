package com.ibmshop.productsapi.resources;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.ibmshop.productsapi.dto.SubCategoriaDTO;
import com.ibmshop.productsapi.entities.Categoria;
import com.ibmshop.productsapi.entities.SubCategoria;
import com.ibmshop.productsapi.services.CategoriaService;
import com.ibmshop.productsapi.services.SubCategoriaService;

import jakarta.validation.Valid;

@RestController
@RequestMapping(value = "/subcategorias")
public class SubCategoriaResource {

	@Autowired
	private SubCategoriaService subcategoriaService;
	
	@Autowired
	private CategoriaService categoriaService;
	

	@GetMapping
	public ResponseEntity<List<SubCategoriaDTO>> findAll() {
		List<SubCategoria> list = subcategoriaService.findAll();
		List<SubCategoriaDTO> listDto = list.stream().map(x -> new SubCategoriaDTO(x)).collect(Collectors.toList());
		return ResponseEntity.ok().body(listDto);
	}

	@GetMapping(value = "/{id}")
	public ResponseEntity<SubCategoriaDTO> findById(@PathVariable Long id) {
		SubCategoria obj = subcategoriaService.findById(id);
		SubCategoriaDTO objDTO = new SubCategoriaDTO(obj);
		return ResponseEntity.ok().body(objDTO);
	}
	
	@GetMapping(value = "/nomeSubCategoria{nomeSubCategoria}")
	public ResponseEntity<List<SubCategoriaDTO>> findByName(@RequestParam(value = "nomeSubCategoria") @PathVariable String nomeSubCategoria) {
		
		List<SubCategoria> list = subcategoriaService.findByNomeSubCategoria(nomeSubCategoria);
		List<SubCategoriaDTO> listDto = list.stream().map(x -> new SubCategoriaDTO(x)).collect(Collectors.toList());
		return ResponseEntity.ok().body(listDto);
		}	

	@PostMapping
	public ResponseEntity<Void> insert(@RequestBody @Valid SubCategoriaDTO objdto) {
		Categoria objCategoria = categoriaService.findById(objdto.getId_category());
		SubCategoria obj = subcategoriaService.fromDTO(objdto, objCategoria);
		obj = subcategoriaService.insert(obj);
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("{id}").buildAndExpand(obj.getId()).toUri();
		//SubCategoriaDTO objDto = new SubCategoriaDTO(obj);
		return ResponseEntity.created(uri).build();
	}

	@PutMapping(value = "/{id}")
	public ResponseEntity<SubCategoriaDTO> update(@PathVariable Long id, @RequestBody SubCategoriaDTO objdto) {
		Categoria objCategoria = categoriaService.findById(objdto.getId_category());
		SubCategoria obj = subcategoriaService.fromDTO(objdto, objCategoria);
		obj = subcategoriaService.update(id, obj);
		SubCategoriaDTO objDTO = new SubCategoriaDTO(obj);
		return ResponseEntity.ok().body(objDTO);
	} 
	
	/*@PutMapping("/{id}")
	public ResponseEntity<SubCategoriaDTO> update(@PathVariable Long id, @RequestBody SubCategoriaDTO objDto) {
	    Categoria categoria = categoriaService.findById(objDto.getId_category()); // encontra a categoria pelo ID da DTO
	    SubCategoria subCategoria = subcategoriaService.findById(id); // encontra a subcategoria pelo ID recebido na URL
	    subCategoria.setCategoria(categoria); // atualiza a categoria da subcategoria
	    
	    // atualiza os outros campos da subcategoria com os valores da DTO
	    subCategoria.setNomeSubCategoria(objDto.getNomeSubCategoria());
	    subCategoria.setDescricao(objDto.getDescricao());
	    
	    subCategoria = subcategoriaService.update(id,subCategoria); // salva as atualizações no banco de dados
	    
	    SubCategoriaDTO subCategoriaDto = new SubCategoriaDTO(subCategoria); // converte a subcategoria atualizada para DTO
	    return ResponseEntity.ok().body(subCategoriaDto); // retorna a subcategoria atualizada em forma de DTO
	}*/
		
	@DeleteMapping(value = "/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {	
		subcategoriaService.delete(id);
		return ResponseEntity.noContent().build();
	}
	
}
