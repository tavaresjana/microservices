package com.ibmshop.productsapi.resources.exceptions;

import java.io.Serializable;
import java.time.Instant;
import java.time.LocalDateTime;

public class StandardError implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Instant timestamp;
	//private Long timestamp;
	private Integer status;
	private String error;
	//private String message;

	public StandardError() {
		super();
	}

	

	public StandardError(Instant timestamp, Integer status, String error) {
		super();
		this.timestamp = timestamp;
		this.status = status;
		this.error = error;
	}



	public StandardError(LocalDateTime now, int value, String string, String message, Object object) {
		// TODO Auto-generated constructor stub
	}



	public Instant getTimestamp() {
		return timestamp;
	}



	public void setTimestamp(Instant timestamp) {
		this.timestamp = timestamp;
	}



	public Integer getStatus() {
		return status;
	}



	public void setStatus(Integer status) {
		this.status = status;
	}



	public String getError() {
		return error;
	}



	public void setError(String error) {
		this.error = error;
	}



	
}