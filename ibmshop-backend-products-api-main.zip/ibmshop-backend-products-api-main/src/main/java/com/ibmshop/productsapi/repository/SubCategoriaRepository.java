package com.ibmshop.productsapi.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ibmshop.productsapi.entities.Categoria;
import com.ibmshop.productsapi.entities.SubCategoria;

public interface SubCategoriaRepository extends JpaRepository<SubCategoria, Long> {

	@Query(value = "select u from SubCategoria u where u.nomeSubCategoria like %?1%")
	List<SubCategoria> findByNomeSubCategoria(String nomeSubCategoria);



}
