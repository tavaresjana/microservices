package com.ibmshop.productsapi.resources;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.ibmshop.productsapi.dto.ProdutoDTO;
import com.ibmshop.productsapi.entities.Produto;
import com.ibmshop.productsapi.entities.SubCategoria;
import com.ibmshop.productsapi.services.ProdutoService;
import com.ibmshop.productsapi.services.SubCategoriaService;

import jakarta.validation.Valid;

@RestController
@RequestMapping(value = "/produtos")
public class ProdutoResource {

	@Autowired
	private ProdutoService produtoService;
	@Autowired
	private SubCategoriaService subCategoriaService;

	@GetMapping
	public ResponseEntity<List<ProdutoDTO>> findAll() {
		List<Produto> list = produtoService.findAll();
		List<ProdutoDTO> listDto = list.stream().map(x -> new ProdutoDTO(x)).collect(Collectors.toList());
		return ResponseEntity.ok().body(listDto);
	}

	@GetMapping(value = "/{id}")
	public ResponseEntity<ProdutoDTO> findById(@PathVariable Long id) {
		Produto obj = produtoService.findById(id);
		ProdutoDTO objDTO = new ProdutoDTO(obj);
		return ResponseEntity.ok().body(objDTO);
	}
	
	@GetMapping(value = "/sku{sku}")
	public ResponseEntity<ProdutoDTO> findBySku(@RequestParam(value = "sku")@PathVariable int sku) {
		Produto obj = produtoService.findBySku(sku);
		ProdutoDTO objDTO = new ProdutoDTO(obj);
		return ResponseEntity.ok().body(objDTO);
	}
	
	@GetMapping(value = "/nomeProduto{nomeProduto}")
	public ResponseEntity<List<ProdutoDTO>> findByName(@RequestParam(value = "nomeProduto") @PathVariable String nomeProduto) {
		
		List<Produto> list = produtoService.findByNomeProduto(nomeProduto);
		List<ProdutoDTO> listDto = list.stream().map(x -> new ProdutoDTO(x)).collect(Collectors.toList());
		return ResponseEntity.ok().body(listDto);
		}	

	@PostMapping
	public ResponseEntity<Void> insert(@RequestBody @Valid ProdutoDTO objdto) {
		SubCategoria objSubcategoria = subCategoriaService.findById(objdto.getId_SubCategoria());
		Produto obj = produtoService.fromDTO(objdto, objSubcategoria);
		obj = produtoService.insert(obj);
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("{id}").buildAndExpand(obj.getId()).toUri();
		//ProdutoDTO objDto = new ProdutoDTO(obj);
		return ResponseEntity.created(uri).build();
	}

	@PutMapping(value = "/{id}")
	public ResponseEntity<ProdutoDTO> update(@PathVariable Long id, @RequestBody ProdutoDTO objdto) {
		SubCategoria objSubcategoria = subCategoriaService.findById(objdto.getId_SubCategoria());
		Produto obj = produtoService.fromDTO(objdto, objSubcategoria);
		obj = produtoService.update(id, obj);
		ProdutoDTO objDTO = new ProdutoDTO(obj);
		return ResponseEntity.ok().body(objDTO);
	}
	
	@PutMapping("/{id}/estoque")
	public ResponseEntity<ProdutoDTO> atualizarEstoque(@PathVariable Long id, @RequestBody ProdutoDTO produtoDTO) {
	    Produto produto = produtoService.atualizarEstoque(id, produtoDTO.getEstoque());
	    ProdutoDTO produtoDTOAtualizado = new ProdutoDTO(produto);
	    return ResponseEntity.ok(produtoDTOAtualizado);
	}
	
	@PutMapping("/{id}/ativo")
	public ResponseEntity<ProdutoDTO> atualizarStatusProduto(@PathVariable Long id) {
	    Produto produto = produtoService.atualizarStatusProduto(id);
	    ProdutoDTO produtoDTOAtualizado = new ProdutoDTO(produto);
	    return ResponseEntity.ok(produtoDTOAtualizado);
	}
	
	@PutMapping(value = "/reativar/{id}")
	public ResponseEntity<Void> reativar(@PathVariable Long id) {		
		produtoService.reativarStatusProduto(id);
		return ResponseEntity.noContent().build();
	}
	
	@DeleteMapping(value = "/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {	
		produtoService.delete(id);
		return ResponseEntity.noContent().build();
	}

}
