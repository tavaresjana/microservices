package com.ibmshop.productsapi.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibmshop.productsapi.dto.CategoriaDTO;
import com.ibmshop.productsapi.entities.Categoria;
import com.ibmshop.productsapi.entities.Produto;
import com.ibmshop.productsapi.repository.CategoriaRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class CategoriaService {

	@Autowired
	private CategoriaRepository categoriaRepository;

	// Métodos de Consulta.

		// Consulta - FindAll
	public List<Categoria> findAll() {
		return categoriaRepository.findAll();
	}

	// Consulta - FindById
	public Categoria findById(Long id) {
		Optional<Categoria> obj = categoriaRepository.findById(id);
		if (obj.isEmpty()) {
			throw new EntityNotFoundException(
					"Desculpe, não foi possível encontrar uma categoria com este id. Verifique e tente novamente.");
		}
		return obj.get();
	}

	// Consulta - FindByNomeCategoria
	public List<Categoria> findByNomeCategoria(String nomeCategoria) {
		List<Categoria> obj = categoriaRepository.findByNomeCategoria(nomeCategoria);
		if (obj.isEmpty()) {
	        throw new EntityNotFoundException("Desculpe, não foi possível encontrar uma categoria com este nome. Verifique e tente novamente.");
	    }
		return obj;
	}

	//POST de Categoria
	public Categoria insert(Categoria obj) {
		List<Categoria> existeCategoria = categoriaRepository.findByNomeCategoria(obj.getNomeCategoria());
		
        if (!existeCategoria.isEmpty()) {
            throw new IllegalArgumentException("Já existe uma categoria com esse nome!");
        }

		return categoriaRepository.save(obj);
	}

	//PUT de Categoria
	public Categoria update(Long id, Categoria obj) {
		Optional<Categoria> entidadeCategoria = categoriaRepository.findById(id);
		if (entidadeCategoria.isEmpty()) {
			throw new EntityNotFoundException(
					"Desculpe, não foi possível encontrar uma categoria com este id. Verifique e tente novamente.");
		}
		Categoria categoria = entidadeCategoria.get();	
		updateCategoria(categoria, obj);
		return categoriaRepository.save(entidadeCategoria.get());
	}

	private void updateCategoria(Categoria categoria, Categoria obj) {
		categoria.setNomeCategoria(obj.getNomeCategoria());
	}

	// DELETE de Categoria
	public void delete(Long id) {
		categoriaRepository.deleteById(id);
	}
	
	public Categoria fromDTO(CategoriaDTO objdto) {
		return new Categoria(objdto.getId(), objdto.getNomeCategoria());
	}

}
