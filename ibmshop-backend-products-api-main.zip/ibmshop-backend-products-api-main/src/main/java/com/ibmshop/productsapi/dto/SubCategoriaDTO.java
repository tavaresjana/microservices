package com.ibmshop.productsapi.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.validator.constraints.Length;

import com.ibmshop.productsapi.entities.Produto;
import com.ibmshop.productsapi.entities.SubCategoria;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class SubCategoriaDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;
	
	@NotBlank
	@Length(min = 2, max = 45, message = "Nome da subcategoria deve ter entre 2 e 45 caracteres")
	private String nomeSubCategoria;
	
	@NotBlank
	@Length(min = 2, max = 250, message = "Descrição da subcategoria deve ter entre 2 e 250 caracteres")
	private String descricao;

	private List<ProdutoDTO> produtoDtoLista = new ArrayList<>();

	// @JsonAlias("categoria")
	@NotNull(message = "O ID da categoria não pode ser nulo.")
	@Min(value = 1, message = "O ID da categoria deve ser maior que zero.")
	private Long id_category;

	// CategoriaDTO categoriaDto;

	public SubCategoriaDTO() {

	}

	public SubCategoriaDTO(SubCategoria obj) {
		super();
		this.id = obj.getId();
		this.nomeSubCategoria = obj.getNomeSubCategoria();
		this.descricao = obj.getDescricao();
		this.id_category = obj.getCategoria().getId();
		// categoriaDto = new CategoriaDTO(obj.getCategoria());
		/*
		 * itera sobre uma lista de produtos e cria uma lista correspondente de objetos
		 * "ProdutoDTO" a partir dos produtos originais.
		 */
		for (Produto produto : obj.getProdutos()) {
			ProdutoDTO produtoDto = new ProdutoDTO(produto);
			produtoDtoLista.add(produtoDto);
		}

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNomeSubCategoria() {
		return nomeSubCategoria;
	}

	public void setNomeSubCategoria(String nomeSubCategoria) {
		this.nomeSubCategoria = nomeSubCategoria;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	public Long getId_category() {
		return id_category;
	}

	public void setId_category(Long id_category) {
		this.id_category = id_category;
	}
	
	public List<ProdutoDTO> getProdutoDtoLista() {
		return produtoDtoLista;
	}

	public void setProdutoDtoLista(List<ProdutoDTO> produtoDtoLista) {
		this.produtoDtoLista = produtoDtoLista;
	}
	

}
