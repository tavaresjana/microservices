package com.ibmshop.productsapi.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ibmshop.productsapi.entities.Categoria;

public interface CategoriaRepository extends JpaRepository<Categoria, Long> {

	
	@Query(value = "select u from Categoria u where u.nomeCategoria like %?1%")
	List<Categoria> findByNomeCategoria(String nomeCategoria);

}
