package com.ibmshop.productsapi.services;

import java.util.List;
import java.util.Optional;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibmshop.productsapi.dto.SubCategoriaDTO;
import com.ibmshop.productsapi.entities.Categoria;
import com.ibmshop.productsapi.entities.SubCategoria;
import com.ibmshop.productsapi.repository.CategoriaRepository;
import com.ibmshop.productsapi.repository.SubCategoriaRepository;

import ch.qos.logback.classic.Logger;
import jakarta.persistence.EntityNotFoundException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SubCategoriaService {

	@Autowired
	private SubCategoriaRepository subCategoriaRepository;

	@Autowired
	private CategoriaRepository categoriaRepository;
	
	private org.slf4j.Logger log = LoggerFactory.getLogger(SubCategoriaService.class);

	// Métodos de Consulta.

	// Consulta - FindAll
	public List<SubCategoria> findAll() {
		return subCategoriaRepository.findAll();
	}

	// Consulta - FindById
	public SubCategoria findById(Long id) {
		Optional<SubCategoria> obj = subCategoriaRepository.findById(id);
		if (obj.isEmpty()) {
			throw new EntityNotFoundException(
					"Desculpe, não foi possível encontrar uma subcategoria com este id. Verifique e tente novamente.");
		}
		return obj.get();
	}

	// Consulta - FindByNomeCategoria
	public List<SubCategoria> findByNomeSubCategoria(String nomeSubCategoria) {
		List<SubCategoria> obj = subCategoriaRepository.findByNomeSubCategoria(nomeSubCategoria);
		if (obj.isEmpty()) {
			throw new EntityNotFoundException(
					"Desculpe, não foi possível encontrar uma subcategoria com este nome. Verifique e tente novamente.");
		}
		obj = subCategoriaRepository.findByNomeSubCategoria(nomeSubCategoria);
		return obj;
	}

	// Métodos de Manutenção

	// POST de Subcategoria
	public SubCategoria insert(SubCategoria obj) {
		List<SubCategoria> existeSubcategoria = subCategoriaRepository
				.findByNomeSubCategoria(obj.getNomeSubCategoria());

		if (!existeSubcategoria.isEmpty()) {
			throw new IllegalArgumentException("Já existe uma subcategoria com esse nome!");
		}
		return subCategoriaRepository.save(obj);
	}

	// PUT de Subcategoria
	/*public SubCategoria update(Long id, SubCategoria obj) {
	log.info("valor do id: "+id);
	log.info("valor do obj: "+obj);
		Optional<SubCategoria> entidadeSubCategoria = subCategoriaRepository.findById(id);
		SubCategoria subCategoria = entidadeSubCategoria.get();
	log.info("valor da subcat: "+subCategoria);
		
		 Optional<Categoria> entidadeCategoria = categoriaRepository.findById(subCategoria.getCategoria().getId());
		 Categoria categoria = entidadeCategoria.get();
	log.info("valor da categoria"+categoria);
		 
		updateCategoria(categoria, obj);
		updateSubCategoria(subCategoria, obj);
		categoriaRepository.save(categoria);
		return subCategoriaRepository.save(entidadeSubCategoria.get());
	}
	*/
	public SubCategoria update(Long id, SubCategoria obj) {
	    Optional<SubCategoria> entidadeSubCategoria = subCategoriaRepository.findById(id);
	    if (entidadeSubCategoria.isEmpty()) {
	        throw new EntityNotFoundException("Não foi possível encontrar uma subcategoria com o ID fornecido.");
	    }
	    SubCategoria subCategoria = entidadeSubCategoria.get();
	    
	    Optional<Categoria> entidadeCategoria = categoriaRepository.findById(subCategoria.getCategoria().getId());
	    Categoria categoria = entidadeCategoria.get();
	    
	    updateCategoria(categoria, obj);
	    updateSubCategoria(subCategoria, obj);
	    categoriaRepository.save(categoria);
	    subCategoria = subCategoriaRepository.save(subCategoria);
	    return subCategoria;
	}
	
	protected void updateCategoria(Categoria categoria, SubCategoria obj) {
		categoria.setNomeCategoria(obj.getNomeSubCategoria());
	}

	protected void updateSubCategoria(SubCategoria subCategoria, SubCategoria obj) {
		subCategoria.setNomeSubCategoria(obj.getNomeSubCategoria());
		subCategoria.setDescricao(obj.getDescricao());
	}

	// DELETE de Subcategoria
	public void delete(Long id) {
		subCategoriaRepository.deleteById(id);
	}

	public SubCategoria fromDTO(SubCategoriaDTO objDTO, Categoria objCategoria) {
		return new SubCategoria(objDTO.getId(), objDTO.getNomeSubCategoria(), objDTO.getDescricao(), objCategoria);
	}
}
