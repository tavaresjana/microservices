package com.ibmshop.productsapi.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.validator.constraints.Length;

import com.ibmshop.productsapi.entities.Categoria;
import com.ibmshop.productsapi.entities.SubCategoria;

import jakarta.validation.constraints.NotBlank;

public class CategoriaDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;
	
	@NotBlank
	@Length(min = 2, max = 45, message = "Nome da categoria deve ter entre 2 e 45 caracteres")
	private String nomeCategoria;
	
	private List<SubCategoriaDTO> subCategoriaDtoLista = new ArrayList<>();

	public CategoriaDTO() {

	}

	public CategoriaDTO(Categoria obj) {
		id = obj.getId();
		nomeCategoria = obj.getNomeCategoria();

		/*
		 * Esse código está convertendo cada objeto "SubCategoria" em um objeto
		 * "SubCategoriaDTO" e adicionando-o a uma lista (subCategoriaDtoLista) de
		 * objetos "SubCategoriaDTO".
		 */
		for (SubCategoria subCategoria : obj.getSubcategoria()) {
			SubCategoriaDTO subCategoriaDto = new SubCategoriaDTO(subCategoria);
			subCategoriaDtoLista.add(subCategoriaDto);
		}
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNomeCategoria() {
		return nomeCategoria;
	}

	public void setNomeCategoria(String nomeCategoria) {
		this.nomeCategoria = nomeCategoria;
	}

	public List<SubCategoriaDTO> getSubCategoriaDtoLista() {
		return subCategoriaDtoLista;
	}

	public void setSubCategoriaDtoLista(List<SubCategoriaDTO> subCategoriaDtoLista) {
		this.subCategoriaDtoLista = subCategoriaDtoLista;
	}

}
