package com.ibmshop.productsapi.entities;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ibmshop.productsapi.dto.CategoriaDTO;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_categoria")
public class Categoria {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(nullable = true, unique = true)
	private String nomeCategoria;

	@PrimaryKeyJoinColumn
	@JsonIgnore
	@OneToMany(mappedBy = "categoria", cascade = CascadeType.PERSIST)
	private List<SubCategoria> subcategoria = new ArrayList<>();

	public Categoria() {

	}

	public Categoria(Long id, String nomeCategoria) {
		super();
		this.id = id;
		this.nomeCategoria = nomeCategoria;
	}

	public Categoria(CategoriaDTO objDto) {
		super();
		this.id = objDto.getId();
		this.nomeCategoria = objDto.getNomeCategoria();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNomeCategoria() {
		return nomeCategoria;
	}

	public void setNomeCategoria(String nomeCategoria) {
		this.nomeCategoria = nomeCategoria;
	}

	public List<SubCategoria> getSubcategoria() {
		return subcategoria;
	}

	public void setSubcategoria(List<SubCategoria> subcategoria) {
		this.subcategoria = subcategoria;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Categoria other = (Categoria) obj;
		return Objects.equals(id, other.id);
	}

}
