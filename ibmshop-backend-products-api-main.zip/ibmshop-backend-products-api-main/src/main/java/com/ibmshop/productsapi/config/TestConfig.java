package com.ibmshop.productsapi.config;

/*	@Configuration
	@Profile("test")
	public class TestConfig implements CommandLineRunner {

		@Autowired
		private ProdutoRepository produtoRepository;
		@Autowired
		private SubCategoriaRepository subCategoriaRepository;
		@Autowired
		private CategoriaRepository categoriaRepository;
		@Override
		public void run(String... args) throws Exception {

		//	Produto p1 = new Produto(null, 1234, "Moto g4", "Celular motorola g4, 5ram, 6 memória", 55.00, 1, (new SubCategoria(null, "telefone", "telefone celular", (new Categoria(null, "NomeCategoria")))));
		
		//	Produto p2 = new Produto(null, 456, "Lápis de cor", "Lápis FaberCastell, ponta n.2, preto", 5.50, 4);
		//	Produto p3 = new Produto(null, 789, "Lápis", "Lápis Bic, ponta simples, BobEsponja", 2.00, 5);
		//
			//produtoRepository.saveAll(Arrays.asList(p1));
		
			//produtoRepository.saveAll(Arrays.asList(p2));
			//produtoRepository.saveAll(Arrays.asList(p3)); 
		}
}*/
