package com.ibmshop.productsapi.services;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibmshop.productsapi.dto.ProdutoDTO;
import com.ibmshop.productsapi.entities.Produto;
import com.ibmshop.productsapi.entities.SubCategoria;
import com.ibmshop.productsapi.repository.ProdutoRepository;
import com.ibmshop.productsapi.repository.SubCategoriaRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class ProdutoService {

	@Autowired
	private ProdutoRepository produtoRepository;

	@Autowired
	private SubCategoriaRepository subcategoriaRepository;

// Métodos de Consulta.

	// Consulta - FindAll
	public List<Produto> findAll() {
		return produtoRepository.findAll();
	}

	// Consulta - FindById
	public Produto findById(Long id) {
		Optional<Produto> obj = produtoRepository.findById(id);
		if (obj.isEmpty()) {
			throw new EntityNotFoundException(
					"Desculpe, não foi possível encontrar um produto com este id. Verifique e tente novamente.");
		}
		return obj.get();
	}

	// Consulta - FindBySku
	public Produto findBySku(int sku) {
		Optional<Produto> obj = produtoRepository.findBySku(sku);
		if (obj.isEmpty()) {
			throw new EntityNotFoundException(
					"Desculpe, não foi possível encontrar um produto com este sku. Verifique e tente novamente.");
		}
		return obj.get();
	}

	// Consulta - FindByNomeProduto
	public List<Produto> findByNomeProduto(String nomeProduto) {

		List<Produto> obj = produtoRepository.findByNomeProduto(nomeProduto);
		if (obj.isEmpty()) {
			throw new EntityNotFoundException(
					"Desculpe, não foi possível encontrar um produto com este nome. Verifique e tente novamente.");
		}
		obj = produtoRepository.findByNomeProduto(nomeProduto);
		return obj;
	}

// Métodos de Manutenção.

	// POST de Produto	
	 public Produto insert(Produto obj) {
        // Verifica se já existe um produto com o mesmo nome
        Optional<Produto> existeProduto = produtoRepository.findBySku(obj.getSku());

        if (existeProduto.isPresent()) {
            throw new IllegalArgumentException("Já existe um produto com esse Sku!");
        }
        if (obj.getEstoque() == BigDecimal.ZERO){
    			obj.setAtivo(false);
    		}
        // Define a data de criação do produto
       // obj.setDataCriacao(LocalDateTime.now());
        obj.setDataCriacao(obj.getDataCriacao());

        // Salva o produto no banco de dados
        return produtoRepository.save(obj);
    }
	

	// PUT de Produto
	public Produto update(Long id, Produto obj) {
		Optional<Produto> entidadeProduto = produtoRepository.findById(id);
		Produto produto = entidadeProduto.get();

		// Verifica se o id da subcategoria do produto foi alterado
		if (!produto.getSubCategoria().getId().equals(obj.getSubCategoria().getId())) {
			// Busca a nova subcategoria no banco de dados
			Optional<SubCategoria> entidadeSubcategoria = subcategoriaRepository
					.findById(obj.getSubCategoria().getId());
			SubCategoria novaSubcategoria = entidadeSubcategoria.get();

			// Atualiza o campo de subcategoria do produto com a nova subcategoria
			produto.setSubCategoria(novaSubcategoria);
		}

		// Atualiza os outros campos do produto
		updateData(entidadeProduto, obj);
		updateProduto(produto, obj);

		return produtoRepository.save(produto);
	}

	private void updateData(Optional<Produto> entidadeProduto, Produto obj) {
		entidadeProduto.get().setNomeProduto(obj.getNomeProduto());
		entidadeProduto.get().setDescricao(obj.getDescricao());
		entidadeProduto.get().setValorUnitario(obj.getValorUnitario());
	}

	private void updateProduto(Produto produto, Produto obj) {
		// produto.setSku(obj.getSku());
		produto.setNomeProduto(obj.getNomeProduto());
		produto.setDescricao(obj.getDescricao());
		produto.setEstoque(obj.getEstoque());
		produto.setValorUnitario(obj.getValorUnitario());
	}

	//- Quando o estoque do produto chegar a zero, ativo deve receber o valor 'false' automaticamente.
	private void mudarStatusEstoqueProduto(Long id) {
		Produto produto = produtoRepository.findById(id)
	            .orElseThrow(() -> new EntityNotFoundException("Produto não encontrado com o ID: " + id));
		
		if(produto.getEstoque() == BigDecimal.ZERO) {
			produto.setAtivo(false);
			produtoRepository.save(produto);
		}
	}
	
	//atualizar estoque
	public Produto atualizarEstoque(Long id, BigDecimal estoque) {
	    Produto produto = produtoRepository.findById(id)
	            .orElseThrow(() -> new EntityNotFoundException("Produto não encontrado com o ID: " + id));

	    produto.setEstoque(estoque);
	  //teste
	    
	    if(produto.getEstoque().compareTo(BigDecimal.ZERO) == 0) {
			produto.setAtivo(false);
	    } else if (produto.getEstoque().compareTo(BigDecimal.ZERO) > 0){
	    	produto.setAtivo(true);
	    }

	    return produtoRepository.save(produto);
	}
	
	public Produto reativarStatusProduto (Long id) {
		Optional<Produto> obj = produtoRepository.findById(id);
			obj.get().setAtivo(true);	
		return produtoRepository.save(obj.get());
	}
	
	public Produto atualizarStatusProduto (Long id) {
		Optional<Produto> obj = produtoRepository.findById(id);
			obj.get().setAtivo(false);	
		return produtoRepository.save(obj.get());
	}
	
	
	public void delete(Long id) {
		Optional<Produto> obj = produtoRepository.findById(id);
		obj.get().setAtivo(false);
		produtoRepository.save(obj.get());
	}
	
	/* DELETE de Produto
	public void delete(Long id) {
		produtoRepository.deleteById(id);
	}*/
	
	
	public Produto fromDTO(ProdutoDTO objdto, SubCategoria objSubcategoria) {
		return new Produto(objdto.getId(), objdto.getSku(), objdto.getNomeProduto(), objdto.getDescricao(),
				objdto.getValorUnitario(), objdto.getEstoque(), objSubcategoria);
	}

}
