package com.ibmshop.productsapi.resources;

import static com.ibmshop.productsapi.common.Constants.CATEGORIA;
import static com.ibmshop.productsapi.common.Constants.SUBCATEGORIA;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ibmshop.productsapi.entities.SubCategoria;
import com.ibmshop.productsapi.repository.SubCategoriaRepository;
import com.ibmshop.productsapi.services.SubCategoriaService;

import jakarta.persistence.EntityNotFoundException;

@ExtendWith(MockitoExtension.class)
public class SubCategoriaResourcesTeste {

//TESTES DE SUBCATEGORIA
	@InjectMocks
	private SubCategoriaService subcategoriaService;

	@Mock
	private SubCategoriaRepository subcategoriaRepository;

	@Test
	@DisplayName("Teste para buscar Subcategoria por Id")
	public void getSubcategoria_ByExistingById_ReturnsSubcategoria() {
		when(subcategoriaRepository.findById(1L)).thenReturn(Optional.of(SUBCATEGORIA));
		Optional<SubCategoria> subcategoriaTest = Optional.ofNullable(subcategoriaService.findById(1L));
	
		assertThat(subcategoriaTest).isNotEmpty();
		assertThat(subcategoriaTest.get()).isEqualTo(SUBCATEGORIA);
	}

	@Test
	@DisplayName("Teste para buscar Subcategoria por Id inexistente")
	public void getSubcategoria_ByUnexistingId_ReturnsThrowsException() {
		when(subcategoriaRepository.findById(1L)).thenReturn(Optional.empty());
		assertThrows(EntityNotFoundException.class, () -> {
			subcategoriaService.findById(1L);
		});
		
	}

	@Test
	@DisplayName("Teste para buscar Subcategoria por Nome")
	public void getSubCategoria_ByExistingNome_ReturnsSubCategoria() {
	    when(subcategoriaRepository.findByNomeSubCategoria("Blusas")).thenReturn(List.of(SUBCATEGORIA));
	    List<SubCategoria> subcategoriaTest = subcategoriaService.findByNomeSubCategoria("Blusas");
	    
	    assertThat(subcategoriaTest).hasSize(1);
	    assertThat(subcategoriaTest.get(0)).isEqualTo(CATEGORIA);
	    assertThat(subcategoriaTest.get(0).getNomeSubCategoria()).hasSizeGreaterThan(2).hasSizeLessThan(46);
	    }
	
	@Test
	@DisplayName("Teste para buscar Subcategoria por Nome inexistente")
	public void getSubCategoria_ByUnexistingNome_ReturnsThrowsException() {
	when(subcategoriaRepository.findByNomeSubCategoria("ana")).thenReturn(List.of());
	/*Caso não houvesse as exceptions, seria dessa forma:
	 * List<Categoria> categoriaTest = categoriaService.findByNomeCategoria("ana");
	assertThat(categoriaTest).isEmpty();*/
	
	assertThrows(EntityNotFoundException.class, () -> {
		subcategoriaService.findByNomeSubCategoria("ana");
	});
	}
}
