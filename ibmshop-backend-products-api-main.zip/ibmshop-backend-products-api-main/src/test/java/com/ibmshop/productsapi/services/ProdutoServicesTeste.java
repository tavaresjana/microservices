package com.ibmshop.productsapi.services;

import static com.ibmshop.productsapi.common.Constants.INVALID_PRODUTO;
import static com.ibmshop.productsapi.common.Constants.PRODUTO;
import static com.ibmshop.productsapi.common.Constants.SUBCATEGORIA;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ibmshop.productsapi.entities.Categoria;
import com.ibmshop.productsapi.entities.Produto;
import com.ibmshop.productsapi.entities.SubCategoria;
import com.ibmshop.productsapi.repository.CategoriaRepository;
import com.ibmshop.productsapi.repository.ProdutoRepository;
import com.ibmshop.productsapi.repository.SubCategoriaRepository;

import jakarta.persistence.EntityNotFoundException;

@ExtendWith(MockitoExtension.class)
public class ProdutoServicesTeste {

//TESTES DE PRODUTO
	@InjectMocks
	private ProdutoService produtoService;

	@InjectMocks
	private SubCategoriaService subcategoriaService;

	@Mock
	private CategoriaRepository categoriaRepository;

	@Mock
	private SubCategoriaRepository subcategoriaRepository;

	@Mock
	private ProdutoRepository produtoRepository;
	

	@Test
	@DisplayName("Teste para buscar Produto por Id")
	public void getProduto_ByExistingId_ReturnsProduto() {
	    when(produtoRepository.findById(1L)).thenReturn(Optional.of(PRODUTO));
	    Optional<Produto> produtoTest = Optional.ofNullable(produtoService.findById(1L));
	    
	    assertThat(produtoTest).isNotEmpty();
	    assertEquals(produtoTest.get(), PRODUTO);
	}
	
	@Test
	@DisplayName("Teste para buscar Produto por Id inexistente")
	public void getProduto_ByUnexistingId_ReturnsThrowsException() {
		when(produtoRepository.findById(1L)).thenReturn(Optional.empty());
		
		assertThrows(EntityNotFoundException.class, () -> {
			produtoService.findById(1L);
		});
		
	}

	@Test
	@DisplayName("Teste criar Produto com dados válidos")
	public void createProduto_WithValidData_ReturnsProduto() {
		when(produtoRepository.save(PRODUTO)).thenReturn(PRODUTO);
		Produto produtoTest = produtoService.insert(PRODUTO);
		assertThat(produtoTest).as("Produto criado com dados válidos").isEqualTo(PRODUTO);
	}

	@Test
	@DisplayName("Teste criar Produto com dados inválidos")
	public void createProduto_WithInvalidData_ThrowsException() {
		when(produtoRepository.save(INVALID_PRODUTO)).thenThrow(RuntimeException.class);
		 
	    assertThatThrownBy(() -> produtoService.insert(INVALID_PRODUTO)).isInstanceOf(RuntimeException.class);
		}

	@Test
	@DisplayName("Teste para buscar Produto por Nome")
	public void getProduto_ByExistingNome_ReturnsProduto() {
	    when(produtoRepository.findByNomeProduto("Moto g4")).thenReturn(List.of(PRODUTO));
	    List<Produto> produtoTest = produtoService.findByNomeProduto("Moto g4");
	    
	    assertThat(produtoTest).hasSize(1);
	    assertThat(produtoTest.get(0)).isEqualTo(PRODUTO);
	    assertThat(produtoTest.get(0).getNomeProduto()).hasSizeGreaterThan(2).hasSizeLessThan(46);
	    }

	@Test
	@DisplayName("Teste para buscar Produto por Nome inexistente")
	public void getProduto_ByUnexistingNome_ReturnsThrowsException() {
	when(produtoRepository.findByNomeProduto("calça")).thenReturn(List.of());
	/*Caso não houvesse as exceptions, seria dessa forma:
	 * List<Categoria> categoriaTest = categoriaService.findByNomeCategoria("ana");
	assertThat(categoriaTest).isEmpty();*/
	
	assertThrows(EntityNotFoundException.class, () -> {
		produtoService.findByNomeProduto("calça");
	});
	}

	@Test
	@DisplayName("Teste para atualizar um Produto válido")
	public void updateProdutoTest_WithValidData_ReturnsProduto() {
		// criando obj cat
		Categoria cat = new Categoria();
		// tem que criar um lista de subcategorias pois esse atributo é do tipo list na
		// model
		List<SubCategoria> subCatList = new ArrayList<>();
		cat.setId(1L);
		cat.setNomeCategoria("Categoria antiga");

		SubCategoria subcat = new SubCategoria();
		subcat.setId(1L);
		subcat.setNomeSubCategoria("SubCategoria Antiga 1");
		subcat.setDescricao("Essa é uma descricao de subcategoria antiga");
		subcat.setCategoria(cat);
		// adicionando uma subcategoria na minha Lista de subCategoria
		subCatList.add(subcat);
		cat.setSubcategoria(subCatList);

		// salvando o obj subcat
		subcategoriaRepository.save(subcat);
		
		Produto produto = new Produto();
		produto.setId(1L);
		produto.setNomeProduto("Produto de teste");
		produto.setDescricao("Essa é uma descrição para o produto de teste");
		produto.setSku(123445);
		produto.setEstoque(3);
		produto.setValorUnitario(30.00);
		produto.setDataCriacao(LocalDateTime.now());
		produto.setSubCategoria(subcat);
		produtoRepository.save(produto);
		
		// simulando chamada no repository
		when(produtoRepository.findById(1L)).thenReturn(Optional.of(produto));

		// atualizando
		Produto novoProduto = new Produto();

		novoProduto.setNomeProduto("Produto de teste");
		novoProduto.setDescricao("Essa é uma descrição para o produto de teste");
		novoProduto.setEstoque(3);
		novoProduto.setValorUnitario(30.00);
		novoProduto.setSubCategoria(subcat);
		produtoService.update(1L, novoProduto);

		assertNotEquals(produto, novoProduto);
	}
}
