package com.ibmshop.productsapi.resources;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.ibmshop.productsapi.dto.CategoriaDTO;
import com.ibmshop.productsapi.entities.Categoria;
import com.ibmshop.productsapi.services.CategoriaService;

public class CategoriaResourcesTeste {

	@Mock
	private CategoriaService categoriaService;

	@InjectMocks
	private CategoriaResource categoriaResource;

	@Test
	public void testFindAll() {
		// Monta o cenário de teste
		Categoria categoria1 = new Categoria(1L, "Categoria 1");
		Categoria categoria2 = new Categoria(2L, "Categoria 2");

		List<Categoria> listaCategorias = new ArrayList<>();
		listaCategorias.add(categoria1);
		listaCategorias.add(categoria2);

		// Define o comportamento esperado do serviço
		when(categoriaService.findAll()).thenReturn(listaCategorias);

		// Executa o método da controller
		ResponseEntity<List<CategoriaDTO>> responseEntity = categoriaResource.findAll();

		// Verifica se o resultado é o esperado
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(2, responseEntity.getBody().size());
		assertEquals("Categoria 1", responseEntity.getBody().get(0).getNomeCategoria());
		assertEquals("Categoria 2", responseEntity.getBody().get(1).getNomeCategoria());
	}

}
