package com.ibmshop.productsapi.services;

import static com.ibmshop.productsapi.common.Constants.CATEGORIA;
import static com.ibmshop.productsapi.common.Constants.INVALID_CATEGORIA;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ibmshop.productsapi.entities.Categoria;
import com.ibmshop.productsapi.repository.CategoriaRepository;

import jakarta.persistence.EntityNotFoundException;

@ExtendWith(MockitoExtension.class)
public class CategoriaServicesTeste {

//TESTES DE CATEGORIA
	@InjectMocks
	private CategoriaService categoriaService;

	// notação para mockar os dados do repository
	@Mock
	private CategoriaRepository categoriaRepository;

	@Test
	@DisplayName("Teste para buscar Categorias")
	public void getCategoria_ByFindAll_ReturnsCategorias() {
		// criando objeto para ser atualizado
		Categoria cat1 = new Categoria();
		cat1.setNomeCategoria("Categoria 1");
		categoriaRepository.save(cat1);

		Categoria cat2 = new Categoria();
		cat2.setNomeCategoria("Categoria 2");
		categoriaRepository.save(cat2);

		List<Categoria> listaCategorias = new ArrayList<>();
		listaCategorias.add(cat1);
		listaCategorias.add(cat2);
		when(categoriaRepository.findAll()).thenReturn(listaCategorias);

		// chamando o metodo
		categoriaService.findAll();

		// Verificar o resultado
		assertNotNull(listaCategorias);
		assertEquals(listaCategorias.size(), listaCategorias.size());
		assertEquals(cat1, listaCategorias.get(0));
		assertEquals(cat2, listaCategorias.get(1));
	}

	@Test
	@DisplayName("Teste para buscar Categoria por Id")
	public void getCategoria_ByExistingId_ReturnsCategoria() {
	    when(categoriaRepository.findById(1L)).thenReturn(Optional.of(CATEGORIA));
	    Optional<Categoria> categoriaTest = Optional.ofNullable(categoriaService.findById(1L));
	    
	    assertThat(categoriaTest).isNotEmpty();
	    assertThat(categoriaTest.get()).isEqualTo(CATEGORIA);
	}

	@Test
	@DisplayName("Teste para buscar Categoria por Id inexistente")
	public void getCategoria_ByUnexistingId_ReturnsEmpty() {
		when(categoriaRepository.findById(1L)).thenReturn(Optional.empty());
		/*Se fizer o teste usando o conteúdo comentado, gera um erro. Pois o teste pede que retorne empty, mas devido ao tratamento de exceptions isso não ocorre.
		 * Optional<Categoria> categoriaTest = Optional.ofNullable(categoriaService.findById(1L));
		assertThat(categoriaTest).isEmpty();
		Já no exemplo usado abaixo o teste chama o findById dentro do assertThrows e verifica se é lançado uma exception, se for o teste é aprovado.
		*/
		
		assertThrows(EntityNotFoundException.class, () -> {
			categoriaService.findById(1L);
		});
		
	}

	@Test
	@DisplayName("Teste para buscar Categoria por Nome")
	public void getCategoria_ByExistingNome_ReturnsCategoria() {
	    when(categoriaRepository.findByNomeCategoria("NomeCategoria")).thenReturn(List.of(CATEGORIA));
	    List<Categoria> categoriaTest = categoriaService.findByNomeCategoria("NomeCategoria");
	    
	    //verifica se a lista de categorias "categoriasTest" possui tamanho 1
	    assertThat(categoriaTest).hasSize(1);
	    //verifica se o primeiro (e único) objeto da lista retornado pela consulta é igual ao objeto de categoria de teste "CATEGORIA"
	    assertThat(categoriaTest.get(0)).isEqualTo(CATEGORIA);
	    //verifica se o nome da Categoria é maior do que 2 caracteres e menor ou igual a 45
	    assertThat(categoriaTest.get(0).getNomeCategoria()).hasSizeGreaterThan(2).hasSizeLessThan(46);
	    }

	@Test
	@DisplayName("Teste para buscar Categoria por Nome inexistente")
	public void getCategoria_ByUnexistingNome_ReturnsCategoria() {
	when(categoriaRepository.findByNomeCategoria("ana")).thenReturn(List.of());
	/*Caso não houvesse as exceptions, seria dessa forma:
	 * List<Categoria> categoriaTest = categoriaService.findByNomeCategoria("ana");
	assertThat(categoriaTest).isEmpty();*/
	
	assertThrows(EntityNotFoundException.class, () -> {
		categoriaService.findByNomeCategoria("ana");
	});
	}

	@Test
	@DisplayName("Teste criar Categoria com dados válidos")
	public void createCategoria_WithValidData_ReturnsCategoria() {
		when(categoriaRepository.save(CATEGORIA)).thenReturn(CATEGORIA);
		Categoria categoriaTest = categoriaService.insert(CATEGORIA);
		assertThat(categoriaTest).as("Produto criado com dados válidos").isEqualTo(CATEGORIA);
	}

	@Test
	@DisplayName("Teste criar Categoria com dados inválidos")
	public void createCategoria_WithInvalidData_ThrowsException() {
		when(categoriaRepository.save(INVALID_CATEGORIA)).thenThrow(RuntimeException.class);
		 
	    assertThatThrownBy(() -> categoriaService.insert(INVALID_CATEGORIA)).isInstanceOf(RuntimeException.class);
		}

	@Test
	@DisplayName("Teste para atualizar uma categoria válida")
	public void updateCategoriaTest_WithValidData_ReturnsCategoria() {
		
		// criando objeto para ser atualizado
		Categoria categoria = new Categoria();
		categoria.setNomeCategoria("Categoria 1");

		//quando chamar o repo, passando um id qualquer, ele ira retornar uma categoria
		when(categoriaRepository.findById(any())).thenReturn(Optional.of(categoria));
		
		// metodo update sendo chamado
		categoriaService.update(categoria.getId(), categoria);

		// verifica quantas vezes o repository esta chamando o metodo save, se esta chamando uma vez significa que esta certo
		verify(categoriaRepository, times(1)).save(any());
	}

}
