package com.ibmshop.productsapi.services;

import static com.ibmshop.productsapi.common.Constants.INVALID_SUBCATEGORIA;
import static com.ibmshop.productsapi.common.Constants.SUBCATEGORIA;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ibmshop.productsapi.entities.Categoria;
import com.ibmshop.productsapi.entities.SubCategoria;
import com.ibmshop.productsapi.repository.CategoriaRepository;
import com.ibmshop.productsapi.repository.SubCategoriaRepository;

import jakarta.persistence.EntityNotFoundException;

@ExtendWith(MockitoExtension.class)
public class SubCategoriaServicesTeste {


//TESTES DE SUBCATEGORIA
	@InjectMocks
	private SubCategoriaService subcategoriaService;

	@Mock
	private SubCategoriaRepository subcategoriaRepository;
	
	@Mock
	CategoriaRepository categoriaRepository;

	@Test
	@DisplayName("Teste para atualizar uma subcategoria válida")
	public void getSubCategoria_ByFindAll_ReturnsSubcategoria() {
		// criando obj cat 	
		Categoria cat = new Categoria();
		//tem que criar um lista de subcategorias pois esse atributo é do tipo list na model
		List<SubCategoria> subCatList = new ArrayList<>(); 
		cat.setId(1L);
		cat.setNomeCategoria("Categoria 1");
		
		SubCategoria subcat = new SubCategoria();
		subcat.setId(1L);
		subcat.setNomeSubCategoria("SubCategoria 1");
		subcat.setDescricao("Essa é uma descricao de subcategoria 1");
		subcat.setCategoria(cat);
		//adicionando uma subcategoria na minha Lista de subCategoria
		subCatList.add(subcat); 
		cat.setSubcategoria(subCatList);
			
		
		//salvando o obj subcat
		subcategoriaRepository.save(subcat);
		
		
		//simulando chamada no repository
		when(subcategoriaRepository.findById(1L)).thenReturn(Optional.of(subcat));
        when(categoriaRepository.findById(1L)).thenReturn(Optional.of(cat));
        
		// atualizando
        SubCategoria novaSubcat = new SubCategoria();
        
        novaSubcat.setNomeSubCategoria("Nome subcategoria novo 2");
        novaSubcat.setDescricao("descrição de subcategoria tem que ter 2");
        novaSubcat.setCategoria(cat);
        subcategoriaService.update(1L, subcat);
       	
        assertNotEquals(subcat,novaSubcat);
        }
	@Test
	@DisplayName("Teste para buscar Subcategoria por Id")
	public void getSubCategoria_ByExistingId_ReturnsSubCategoria() {
	    when(subcategoriaRepository.findById(1L)).thenReturn(Optional.of(SUBCATEGORIA));
	    Optional<SubCategoria> subcategoriaTest = Optional.ofNullable(subcategoriaService.findById(1L));
	    
	    assertThat(subcategoriaTest).isNotEmpty();
	    assertEquals(subcategoriaTest.get(), SUBCATEGORIA);
	}

	@Test
	@DisplayName("Teste para buscar SubCategoria por Id inexistente")
	public void getSubCategoria_ByUnexistingId_ReturnsThrowsException() {
		when(subcategoriaRepository.findById(1L)).thenReturn(Optional.empty());
		
		assertThrows(EntityNotFoundException.class, () -> {
			subcategoriaService.findById(1L);
		});
		
	}

	@Test
	@DisplayName("Teste para buscar Subcategoria por Nome")
	public void getSubCategoria_ByExistingNome_ReturnsSubCategoria() {
	    when(subcategoriaRepository.findByNomeSubCategoria("Blusas")).thenReturn(List.of(SUBCATEGORIA));
	    List<SubCategoria> subcategoriaTest = subcategoriaService.findByNomeSubCategoria("Blusas");
	    
	    assertThat(subcategoriaTest).hasSize(1);
	    assertThat(subcategoriaTest.get(0)).isEqualTo(SUBCATEGORIA);
	    assertThat(subcategoriaTest.get(0).getNomeSubCategoria()).hasSizeGreaterThan(2).hasSizeLessThan(46);
	    }
	
	@Test
	@DisplayName("Teste para buscar Subcategoria por Nome inexistente")
	public void getSubCategoria_ByUnexistingNome_ReturnsThrowsException() {
	when(subcategoriaRepository.findByNomeSubCategoria("calça")).thenReturn(List.of());
	/*Caso não houvesse as exceptions, seria dessa forma:
	 * List<Categoria> categoriaTest = categoriaService.findByNomeCategoria("ana");
	assertThat(categoriaTest).isEmpty();*/
	
	assertThrows(EntityNotFoundException.class, () -> {
		subcategoriaService.findByNomeSubCategoria("calça");
	});
	}
	
	@Test
	@DisplayName("Teste criar Subcategoria com dados inválidos")
	public void createSubCategoria_WithValidData_ReturnsCategoria() {
		when(subcategoriaRepository.save(SUBCATEGORIA)).thenReturn(SUBCATEGORIA);
		SubCategoria subcategoriaTest = subcategoriaService.insert(SUBCATEGORIA);
		assertThat(subcategoriaTest).as("Subcategoria criada com dados válidos").isEqualTo(SUBCATEGORIA);
	}

	@Test
	@DisplayName("Teste criar SubCategoria com dados inválidos")
	public void createSubCategoria_WithInvalidData_ThrowsException() {
	    when(subcategoriaRepository.save(INVALID_SUBCATEGORIA)).thenThrow(RuntimeException.class);
	    
	    assertThatThrownBy(() -> subcategoriaService.insert(INVALID_SUBCATEGORIA)).isInstanceOf(RuntimeException.class);
	}
	
	@Test
	@DisplayName("Teste para atualizar uma subcategoria válida")
	public void updateSubCategoriaTest_WithValidData_ReturnsSubcategoria() {
		// criando obj cat 	
		Categoria cat = new Categoria();
		//tem que criar um lista de subcategorias pois esse atributo é do tipo list na model
		List<SubCategoria> subCatList = new ArrayList<>(); 
		cat.setId(1L);
		cat.setNomeCategoria("Categoria antiga");
		
		SubCategoria subcat = new SubCategoria();
		subcat.setId(1L);
		subcat.setNomeSubCategoria("SubCategoria Antiga 1");
		subcat.setDescricao("Essa é uma descricao de subcategoria antiga");
		subcat.setCategoria(cat);
		//adicionando uma subcategoria na minha Lista de subCategoria
		subCatList.add(subcat); 
		cat.setSubcategoria(subCatList);
			
		
		//salvando o obj subcat
		subcategoriaRepository.save(subcat);
		
		//simulando chamada no repository
		when(subcategoriaRepository.findById(1L)).thenReturn(Optional.of(subcat));
        when(categoriaRepository.findById(1L)).thenReturn(Optional.of(cat));
        
		// atualizando
        SubCategoria novaSubcat = new SubCategoria();
        
        novaSubcat.setNomeSubCategoria("Nome subcategoria novo 2");
        novaSubcat.setDescricao("descrição de subcategoria tem que ter 2");
        novaSubcat.setCategoria(cat);
        subcategoriaService.update(1L, subcat);
       	
        assertNotEquals(subcat,novaSubcat);
	}
	
}
