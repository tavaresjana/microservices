package com.ibmshop.productsapi.common;

import com.ibmshop.productsapi.entities.Categoria;
import com.ibmshop.productsapi.entities.Produto;
import com.ibmshop.productsapi.entities.SubCategoria;

public class Constants {
	public static final Categoria CATEGORIA = new Categoria(null, "NomeCategoria");
	
	public static final Categoria INVALID_CATEGORIA = new Categoria(null, "");
	
	public static final SubCategoria SUBCATEGORIA = new SubCategoria(null, "Blusas", "Blusas de frio e de calor todas da Disney", (new Categoria(null, "Vestuário")));
	public static final SubCategoria INVALID_SUBCATEGORIA = new SubCategoria(null, "","", (new Categoria(null, "")));
	
	public static final Produto PRODUTO = new Produto(null, 1234, "Moto g4", "Celular motorola g4, 5ram, 6 memória", 55.00, 1, (new SubCategoria(null, "telefone", "telefone celular", (new Categoria(null, "NomeCategoria")))));
	public static final Produto INVALID_PRODUTO = new Produto(null, 1234, "a", "", 0.00, -1, (new SubCategoria(null, "", "", (new Categoria(null, "")))));
}

