package testeconfig;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.ibmshop.productsapi.entities.Categoria;
import com.ibmshop.productsapi.entities.Produto;
import com.ibmshop.productsapi.entities.SubCategoria;
import com.ibmshop.productsapi.repository.CategoriaRepository;
import com.ibmshop.productsapi.repository.ProdutoRepository;
import com.ibmshop.productsapi.repository.SubCategoriaRepository;
/*
@Configuration
	@Profile("test")
	public class ProdutoConfig implements CommandLineRunner {

		@Autowired
		private ProdutoRepository produtoRepository;
		@Autowired
		private SubCategoriaRepository subCategoriaRepository;
		@Autowired
		private CategoriaRepository categoriaRepository;
		@Override
		public void run(String... args) throws Exception {

			Produto p1 = new Produto(1L, 1234, "Moto g4", "Celular motorola g4, 5ram, 6 memória", 55.00, 1, (new SubCategoria(null, "telefone", "telefone celular", (new Categoria(null, "NomeCategoria")))));
		
			Produto p2 = new Produto(2L, 456, "Lápis de cor", "Lápis FaberCastell, ponta n.2, preto", 5.50, 4, (new SubCategoria(null, "Lápis", "Lápis comum", (new Categoria(null, "Papelaria")))));
			Produto p3 = new Produto(3L, 789, "Lápis", "Lápis Bic, ponta simples, BobEsponja", 2.00, 5,(new SubCategoria(null, "Geladeira", "Geladeira duplex", (new Categoria(null, "Eletrodomesticos")))));
		
			produtoRepository.saveAll(Arrays.asList(p1));
		
			produtoRepository.saveAll(Arrays.asList(p2));
			produtoRepository.saveAll(Arrays.asList(p3)); 
		}
		public static Long getProduto(long l) {
			// TODO Auto-generated method stub
			return ProdutoConfig.getProduto(l);
		}
}*/
