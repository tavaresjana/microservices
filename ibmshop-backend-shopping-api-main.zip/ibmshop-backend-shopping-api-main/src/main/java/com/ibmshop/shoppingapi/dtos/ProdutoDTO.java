package com.ibmshop.shoppingapi.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ibmshop.shoppingapi.entities.Produto;

public class ProdutoDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;

	private String nomeProduto;

	private String descricao;

	private int sku;
	
	private BigDecimal estoque;

	private BigDecimal valorUnitario;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "GMT")
	private LocalDateTime dataCriacao;

	protected boolean ativo = true;
	
	private Long id_SubCategoria;

	public ProdutoDTO() {

	}

	public ProdutoDTO(Produto obj) {
		super();
		id = obj.getId();
		sku = obj.getSku();
		nomeProduto = obj.getNomeProduto();
		descricao = obj.getDescricao();
		valorUnitario = obj.getValorUnitario();
		estoque = obj.getEstoque();
		ativo = obj.isAtivo();
		id_SubCategoria = obj.getSubCategoria().getId();
		// subCategoriaDto = new SubCategoriaDTO(obj.getSubCategoria());
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNomeProduto() {
		return nomeProduto;
	}

	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public int getSku() {
		return sku;
	}

	public void setSku(int sku) {
		this.sku = sku;
	}

	public BigDecimal getEstoque() {
		return estoque;
	}

	public void setEstoque(BigDecimal estoque) {
		this.estoque = estoque;
	}

	public BigDecimal getValorUnitario() {
		return valorUnitario;
	}

	public void setValorUnitario(BigDecimal valorUnitario) {
		this.valorUnitario = valorUnitario;
	}

	public LocalDateTime getDataCriacao() {
		return dataCriacao = LocalDateTime.now();
	}

	public void setDataCriacao(LocalDateTime dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public Long getId_SubCategoria() {
		return id_SubCategoria;
	}

	public void setId_SubCategoria(Long id_SubCategoria) {
		this.id_SubCategoria = id_SubCategoria;
	}

	@Override
	public String toString() {
		return "ProdutoDTO [id=" + id + ", nomeProduto=" + nomeProduto + ", descricao=" + descricao + ", sku=" + sku
				+ ", estoque=" + estoque + ", valorUnitario=" + valorUnitario + ", dataCriacao=" + dataCriacao
				+ ", id_SubCategoria=" + id_SubCategoria + "]";
	}

	public boolean isAtivo() {
		return ativo;
	}

	public void setAtivo(boolean ativo) {
		this.ativo = ativo;
	}
	
	

}
