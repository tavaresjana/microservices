package com.ibmshop.shoppingapi.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class PedidoDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;
	private int status_pedido;
	private LocalDateTime dataCriacao;
	private LocalDateTime dataModificacao;
	private Long id_usuario;
	private BigDecimal total;
	
	private List<DetalhesPedidoDTO> detalhesLista = new ArrayList<>();

	@Override
	public String toString() {
		return "PedidoDTO [id=" + id + ", status_pedido=" + status_pedido + ", dataCriacao=" + dataCriacao
				+ ", dataModificacao=" + dataModificacao + ", id_usuario=" + id_usuario + ", detalhesLista="
				+ detalhesLista + "]";
	}

	
}
