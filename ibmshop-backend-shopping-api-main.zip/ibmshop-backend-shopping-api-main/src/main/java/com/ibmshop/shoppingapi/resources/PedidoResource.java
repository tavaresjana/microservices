package com.ibmshop.shoppingapi.resources;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ibmshop.shoppingapi.dtos.PedidoDTO;
import com.ibmshop.shoppingapi.entities.Pedido;
import com.ibmshop.shoppingapi.mapper.PedidoMapperImpl;
import com.ibmshop.shoppingapi.service.PedidoService;

@RestController
@RequestMapping(value = "/pedidos")
public class PedidoResource {

	@Autowired
	private PedidoService pedidoService;

	@Autowired
	private PedidoMapperImpl pedidoMapper;

	@GetMapping
	public ResponseEntity<List<PedidoDTO>> findAll() {
		List<Pedido> list = pedidoService.findAll();
		List<PedidoDTO> listDto = list.stream().map(pedidoMapper::EntidadeParaDto).collect(Collectors.toList());
		return ResponseEntity.ok(listDto);
	}

	@GetMapping(value = "/{id}")
	public ResponseEntity<Pedido> findById(@PathVariable Long id) {
		Pedido obj = pedidoService.findById(id);
		return ResponseEntity.ok(obj);
	}
	
	@GetMapping(value = "/status_pedido{status_pedido}")
	public ResponseEntity<Pedido> findByStatus(@RequestParam(value ="status_pedido") @PathVariable int status_pedido) {
		Pedido obj = pedidoService.findByStatus(status_pedido);
		return ResponseEntity.ok(obj);
	}
	
	@PostMapping
	public ResponseEntity<Pedido> insert(@RequestBody PedidoDTO objdto) {
		Pedido entidadePedido = pedidoService.insert(objdto);
		// objdto = pedidoService.insert(objdto);
		return ResponseEntity.status(HttpStatus.CREATED).body(entidadePedido);
	}
	
	
	
	@DeleteMapping(value = "/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {	
		pedidoService.delete(id);
		return ResponseEntity.noContent().build();
	}
	
	/*
	 * public ResponseEntity<Void> insert(@RequestBody PedidoDTO objdto){ Pedido obj
	 * = pedidoService.fromDTO(objdto); pedidoService.insert(obj); URI uri =
	 * ServletUriComponentsBuilder.fromCurrentRequest().path("{id}").buildAndExpand(
	 * obj.getId()).toUri();
	 * 
	 * PedidoDTO objDto = new PedidoDTO(obj); return
	 * ResponseEntity.created(uri).build(); }
	 */

	/*
	 * @PutMapping(value="/{id}") public ResponseEntity<PedidoDTO> update(Long id,
	 * PedidoDTO objdto){ Pedido obj = pedidoService.fromDTO(objdto); obj =
	 * pedidoService.update(id, obj); PedidoDTO objDTO = new PedidoDTO(obj); return
	 * ResponseEntity.ok().body(objDTO); }
	 */
}
