package com.ibmshop.shoppingapi.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.ibmshop.shoppingapi.dtos.DetalhesPedidoDTO;
import com.ibmshop.shoppingapi.dtos.PedidoDTO;
import com.ibmshop.shoppingapi.dtos.ProdutoDTO;
import com.ibmshop.shoppingapi.entities.Pedido;
import com.ibmshop.shoppingapi.entities.Produto;
import com.ibmshop.shoppingapi.feignclients.ProdutoFeignClient;
import com.ibmshop.shoppingapi.feignclients.UsuarioFeignClient;
import com.ibmshop.shoppingapi.mapper.PedidoMapper;
import com.ibmshop.shoppingapi.mapper.ProdutoMapper;
import com.ibmshop.shoppingapi.repository.PedidoRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class PedidoService {

	private final ProdutoFeignClient produtoFeignClient;

	private final UsuarioFeignClient usuarioFeignClient;

	private final PedidoRepository pedidoRepository;

	private final PedidoMapper pedidoMapper;

	private final ProdutoMapper produtoMapper;

	/*
	 * public PedidoDTO getPedido(Long id) { PedidoDTO pedido =
	 * produtoFeignClient.getPedido(id).getBody(); return pedido; }
	 */

	/*
	 * quando ele acessa meu findall ele usa o parallelStream para acessar
	 * simultaneamente e ele mapea meu pedido
	 */
	public List<Pedido> findAll() {
		return pedidoRepository.findAll().parallelStream().map(p -> {
			p.getDetalhesLista().parallelStream().forEach(dp -> {
				dp.setProduto(produtoMapper.dtoParaEntidade(produtoFeignClient.findById(dp.getId_produto())));
				log.info("Log do FindAll, depois do setProduto{}", dp.getProduto());
			});
			return p;
		}).toList();
	}

	public Pedido findById(Long id) {
		return pedidoRepository.findById(id).map(p -> {
			p.getDetalhesLista().parallelStream().forEach(dp -> {

				dp.setProduto(produtoMapper.dtoParaEntidade(produtoFeignClient.findById(dp.getId_produto())));
				log.info("Depois de set produto do get{}", dp.getProduto());
			});
			return p;
		}).orElseThrow(() -> new RuntimeException("Pedido não encontrado"));

	}

	public Pedido findByStatus(int status_pedido) {
		return pedidoRepository.findByStatus(status_pedido);
	}

	public ProdutoDTO getProduto(Long id) {
		return produtoFeignClient.findById(id);
	}

	public void usuarioExiste(Long id_usuario) {
		if (usuarioFeignClient.findById(id_usuario) == null) {
			throw new RuntimeException("Usuário não existe");
		}
	}

	public Pedido insert(PedidoDTO obj) {
		// Verifica se o usuário existe
		usuarioExiste(obj.getId_usuario());
		// Define a data de criação, data de modificação e status do pedido
		LocalDateTime dataAtual = LocalDateTime.now();
		obj.setDataCriacao(dataAtual);
		obj.setDataModificacao(dataAtual);
		obj.setStatus_pedido(1);

		// Obtém a lista de detalhes do DTO do pedido
		List<DetalhesPedidoDTO> listaDetalhesDto = obj.getDetalhesLista();

		BigDecimal subtotalTotal = BigDecimal.ZERO;
		BigDecimal estoque = BigDecimal.ZERO;
		
		for (DetalhesPedidoDTO detalhesPedidoDto : listaDetalhesDto) {

			// Consulta o produto pelo ID
			Produto produto = produtoMapper
					.dtoParaEntidade(produtoFeignClient.findById(detalhesPedidoDto.getId_produto()));

			// Define o produto no detalhe do pedido
			detalhesPedidoDto.setProduto(produto);

			// Calcula o subtotal do detalhe do pedido
			BigDecimal valorUnitario = produto.getValorUnitario();
			int quantidade = detalhesPedidoDto.getQuantidade();
			BigDecimal subtotal = valorUnitario.multiply(BigDecimal.valueOf(quantidade));
			detalhesPedidoDto.setSubtotal(subtotal);

			produto.setEstoque(produto.getEstoque().subtract(BigDecimal.valueOf(quantidade)));
			produtoFeignClient.atualizarEstoque(produto.getId(), produtoMapper.entidadeParaDto(produto));
			
			if(produto.getEstoque().compareTo(BigDecimal.ZERO) == 0){
				produtoFeignClient.atualizarStatusProduto(produto.getId());
			}
			
			// Adiciona o subtotal ao subtotal total do pedido
			subtotalTotal = subtotalTotal.add(subtotal);
			

		}

		// Cria a entidade Pedido a partir do DTO
		Pedido pedido = pedidoMapper.DtoParaEntidade(obj);

		// Define o subtotal total no pedido
		pedido.setTotal(subtotalTotal);

		// Define o pedido nos detalhes do pedido
		pedido.getDetalhesLista().forEach(detalhesPedido -> detalhesPedido.setPedido(pedido));

		// Salva o pedido no repositório
		return pedidoRepository.save(pedido);

	}


	public void delete(Long id) {
		Optional<Pedido> obj = pedidoRepository.findById(id);
		obj.get().setStatus_pedido(5);
		pedidoRepository.save(obj.get());
	}

	public Pedido update(Long id, Pedido obj) {
		Optional<Pedido> entidadePedido = pedidoRepository.findById(id);
		updateData(entidadePedido, obj);
		return pedidoRepository.save(entidadePedido.get());
	}

	private void updateData(Optional<Pedido> entity, Pedido obj) {
		entity.get().setStatus_pedido(obj.getStatus_pedido());
		entity.get().setDataModificacao(obj.getDataModificacao());
	}

}