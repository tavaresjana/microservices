package com.ibmshop.shoppingapi.dtos;

import java.io.Serializable;
import java.math.BigDecimal;

import org.springframework.http.ResponseEntity;

import com.ibmshop.shoppingapi.entities.Produto;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class DetalhesPedidoDTO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private Produto produto;
	private Long id_produto;
	private int quantidade;
	private BigDecimal subtotal;
	@Override
	public String toString() {
		return "DetalhesPedidoDTO [id=" + id + ", produto=" + produto + ", id_produto=" + id_produto + ", quantidade="
				+ quantidade + ", subtotal=" + subtotal + "]";
	}

	
}
