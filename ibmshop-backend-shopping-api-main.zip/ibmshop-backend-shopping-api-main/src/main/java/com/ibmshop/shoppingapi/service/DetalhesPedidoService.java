package com.ibmshop.shoppingapi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibmshop.shoppingapi.dtos.DetalhesPedidoDTO;
import com.ibmshop.shoppingapi.entities.DetalhesPedido;
import com.ibmshop.shoppingapi.entities.Produto;
import com.ibmshop.shoppingapi.feignclients.ProdutoFeignClient;
/*
@Service
public class DetalhesPedidoService {

	@Autowired
	private DetalhesPedidoRepository detalhesPedidoRepository;

	@Autowired
	private ProdutoFeignClient produtoFeignClient;

	public DetalhesPedido findById(Long id) {
		Optional<DetalhesPedido> obj = detalhesPedidoRepository.findById(id);
		return obj.get();
	}

	public Produto getDetalhesPedido(long id) {
		Produto produto = produtoFeignClient.findById(id).getBody();
		return produto;
		// return new Produto(produto.getId(), produto.getNomeProduto(),
		// produto.getSku(), produto.getDescricao());
	}

	public DetalhesPedido insert(DetalhesPedido obj) {
		// obj.setDataCriacao(obj.getDataCriacao());
		return detalhesPedidoRepository.save(obj);
	}
	
	public DetalhesPedido fromDTO(DetalhesPedidoDTO objDTO) {
		return new DetalhesPedido(objDTO.getId(), objDTO.getProduto(), objDTO.getQuantidade(),objDTO.getSubtotal());
	}

	public List<DetalhesPedido> findAll() {
		return detalhesPedidoRepository.findAll();
	}

	/*
	 * deletar public DetalhesPedidoPedido findById(Long id) {
	 * Optional<DetalhesPedidoPedido> obj =
	 * detalhesDetalhesPedidoRepository.findById(id); return obj.get(); }
	 * 
	 * 
	 * public List<DetalhesPedidoPedido> findAll() { return
	 * detalhesDetalhesPedidoRepository.findAll(); }
	 * 
	 * public Produto getDetalhes(long id) { Produto produto =
	 * produtoFeignClient.findById(id).getBody(); return produto; //return new
	 * Produto(produto.getId(), produto.getNomeProduto(), produto.getSku(),
	 * produto.getDescricao()); }
	 

}*/
