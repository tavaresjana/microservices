package com.ibmshop.shoppingapi.feignclients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ibmshop.shoppingapi.dtos.UsuarioDTO;
import com.ibmshop.shoppingapi.entities.Produto;

@Component
@FeignClient(name = "usuarios-api", url = "http://localhost:8092", path = "/usuarios")
public interface UsuarioFeignClient {

	@GetMapping(value = "/{id}")
	public ResponseEntity<UsuarioDTO> findById(@PathVariable Long id);
	
}
