package com.ibmshop.shoppingapi.resources;

/*@RestController
@RequestMapping(value = "/detalhespedidos")
public class DetalhesPedidoResource {

	@Autowired
	private DetalhesPedidoService detalhesPedidoService;
	
	@GetMapping(value = "/{id}")
	public ResponseEntity<DetalhesPedidoDTO> getDetalhesPedido(Long id){
		DetalhesPedido obj = detalhesPedidoService.findById(id);
		DetalhesPedidoDTO objDTO = new DetalhesPedidoDTO(obj);
		return ResponseEntity.ok().body(objDTO);
	}
	
	@GetMapping
	public ResponseEntity<List<DetalhesPedidoDTO>> findAll(){
		List<DetalhesPedido> list = detalhesPedidoService.findAll();
		List<DetalhesPedidoDTO> listDto =  list.stream().map(x -> new DetalhesPedidoDTO(x)).collect(Collectors.toList());
		return ResponseEntity.ok().body(listDto);
	}
	
 	@PostMapping
	public ResponseEntity<Void> insert(@RequestBody DetalhesPedidoDTO objdto){
		DetalhesPedido obj = detalhesPedidoService.fromDTO(objdto);
		obj = detalhesPedidoService.insert(obj);
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("{id}").buildAndExpand(obj.getId()).toUri();
		
		DetalhesPedidoDTO objDto = new DetalhesPedidoDTO(obj);
		return ResponseEntity.created(uri).build();
		//return null;
	} 
}*/
