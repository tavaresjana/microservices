package com.ibmshop.shoppingapi.dtos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.ibmshop.shoppingapi.entities.Produto;
import com.ibmshop.shoppingapi.entities.SubCategoria;

public class SubCategoriaDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;
	
	
	private String nomeSubCategoria;
	
	
	private String descricao;

	private List<ProdutoDTO> produtoDtoLista = new ArrayList<>();

	
	private Long id_category;

	// CategoriaDTO categoriaDto;

	public SubCategoriaDTO() {

	}

	public SubCategoriaDTO(SubCategoria obj) {
		super();
		this.id = obj.getId();
		this.nomeSubCategoria = obj.getNomeSubCategoria();
		this.descricao = obj.getDescricao();
		this.id_category = obj.getCategoria().getId();
		// categoriaDto = new CategoriaDTO(obj.getCategoria());
		/*
		 * itera sobre uma lista de produtos e cria uma lista correspondente de objetos
		 * "ProdutoDTO" a partir dos produtos originais.
		 */
		for (Produto produto : obj.getProdutos()) {
			ProdutoDTO produtoDto = new ProdutoDTO(produto);
			produtoDtoLista.add(produtoDto);
		}

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNomeSubCategoria() {
		return nomeSubCategoria;
	}

	public void setNomeSubCategoria(String nomeSubCategoria) {
		this.nomeSubCategoria = nomeSubCategoria;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	public Long getId_category() {
		return id_category;
	}

	public void setId_category(Long id_category) {
		this.id_category = id_category;
	}
	
	public List<ProdutoDTO> getProdutoDtoLista() {
		return produtoDtoLista;
	}

	public void setProdutoDtoLista(List<ProdutoDTO> produtoDtoLista) {
		this.produtoDtoLista = produtoDtoLista;
	}
	

}
