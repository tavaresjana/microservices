package com.ibmshop.shoppingapi.dtos;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.ibmshop.shoppingapi.entities.Endereco;
import com.ibmshop.shoppingapi.entities.Usuario;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class EnderecoDTO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Long id;

	
	private String rua;
	
	
	private Integer numero;

	private String cep;

	private String complemento;

	private String bairro;

	private String cidade;

	private String estado;

	Usuario usuario;
	
	PaisDTO paisDto;

	public EnderecoDTO() {
	}

	public EnderecoDTO(Endereco obj) {
		rua = obj.getRua();
		numero = obj.getNumero();
		cep = obj.getCep();
		complemento = obj.getComplemento();
		bairro = obj.getBairro();
		cidade = obj.getCidade();
		estado = obj.getEstado();
		paisDto = new PaisDTO(obj.getPais());
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRua() {
		return rua;
	}

	public void setRua(String rua) {
		this.rua = rua;
	}

	public Integer getNumero() {
		return numero;
	}

	public void setNumero(Integer numero) {
		this.numero = numero;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public PaisDTO getPaisDto() {
		return paisDto;
	}

	public void setPaisDto(PaisDTO paisDto) {
		this.paisDto = paisDto;
	}


}
