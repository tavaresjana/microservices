package com.ibmshop.shoppingapi.entities;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ibmshop.shoppingapi.dtos.SubCategoriaDTO;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_subcategoria")
public class SubCategoria {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(nullable = true, unique = false)
	private String nomeSubCategoria;

	@Column(nullable = true, unique = false)
	private String descricao;

	@ManyToOne
	@JoinColumn(name = "categoria_id")
	Categoria categoria;

	@PrimaryKeyJoinColumn(name = "id_produto")
	@JsonIgnore
	@OneToMany(mappedBy = "subCategoria", targetEntity = Produto.class, cascade = CascadeType.PERSIST)
	private List<Produto> produtos = new ArrayList<>();

	public SubCategoria() {

	}

	public SubCategoria(Long id, String nomeSubCategoria, String descricao, Categoria categoria) {
		super();
		this.id = id;
		this.nomeSubCategoria = nomeSubCategoria;
		this.descricao = descricao;
		this.categoria = categoria;
	}

	public SubCategoria(SubCategoriaDTO objDto) {
		super();
		id=objDto.getId();
		nomeSubCategoria = objDto.getNomeSubCategoria();
		descricao = objDto.getDescricao();
		// categoria = new Categoria(objDto.getCategoriaDto());
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNomeSubCategoria() {
		return nomeSubCategoria;
	}

	public void setNomeSubCategoria(String nomeSubCategoria) {
		this.nomeSubCategoria = nomeSubCategoria;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	public List<Produto> getProdutos() {
		return produtos;
	}

	public void setProdutos(List<Produto> produtos) {
		this.produtos = produtos;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SubCategoria other = (SubCategoria) obj;
		return Objects.equals(id, other.id);
	}

}
