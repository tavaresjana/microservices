package com.ibmshop.shoppingapi.mapper;

import java.math.BigDecimal;

import org.mapstruct.Mapper;

import com.ibmshop.shoppingapi.dtos.ProdutoDTO;
import com.ibmshop.shoppingapi.entities.Produto;

@Mapper(componentModel = "spring")
public interface ProdutoMapper {
	
	/*Produto DtoParaEntidade(ProdutoDTO produtoDto);
	
	ProdutoDTO EntidadeParaDto(Produto produto);

	Produto DtoParaEntidade(BigDecimal valorUnitario);

	ProdutoDTO EntidadeParaDto(ProdutoDTO findById);*/
	
	Produto dtoParaEntidade(ProdutoDTO produtoDto);
	
	ProdutoDTO entidadeParaDto(Produto produto);
	

}