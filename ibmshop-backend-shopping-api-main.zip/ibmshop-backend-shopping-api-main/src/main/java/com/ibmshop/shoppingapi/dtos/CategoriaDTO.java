package com.ibmshop.shoppingapi.dtos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.ibmshop.shoppingapi.entities.Categoria;
import com.ibmshop.shoppingapi.entities.SubCategoria;

public class CategoriaDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;
	
	private String nomeCategoria;
	
	private List<SubCategoriaDTO> subCategoriaDtoLista = new ArrayList<>();

	public CategoriaDTO() {

	}

	public CategoriaDTO(Categoria obj) {
		id = obj.getId();
		nomeCategoria = obj.getNomeCategoria();

		/*
		 * Esse código está convertendo cada objeto "SubCategoria" em um objeto
		 * "SubCategoriaDTO" e adicionando-o a uma lista (subCategoriaDtoLista) de
		 * objetos "SubCategoriaDTO".
		 */
		for (SubCategoria subCategoria : obj.getSubcategoria()) {
			SubCategoriaDTO subCategoriaDto = new SubCategoriaDTO(subCategoria);
			subCategoriaDtoLista.add(subCategoriaDto);
		}
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNomeCategoria() {
		return nomeCategoria;
	}

	public void setNomeCategoria(String nomeCategoria) {
		this.nomeCategoria = nomeCategoria;
	}

	public List<SubCategoriaDTO> getSubCategoriaDtoLista() {
		return subCategoriaDtoLista;
	}

	public void setSubCategoriaDtoLista(List<SubCategoriaDTO> subCategoriaDtoLista) {
		this.subCategoriaDtoLista = subCategoriaDtoLista;
	}

}
