package com.ibmshop.shoppingapi.mapper;

import org.mapstruct.Mapper;

import com.ibmshop.shoppingapi.dtos.PedidoDTO;
import com.ibmshop.shoppingapi.entities.Pedido;

@Mapper(componentModel = "spring")
public interface PedidoMapper {
	
	Pedido DtoParaEntidade(PedidoDTO pedidoDto);
	
	PedidoDTO EntidadeParaDto(Pedido pedido);
}