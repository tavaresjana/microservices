package com.ibmshop.shoppingapi.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "tb_pedido")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class Pedido implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private Long id;
	@Column
	private int status_pedido;
	@Column
	private LocalDateTime dataCriacao;
	@Column
	private LocalDateTime dataModificacao;
	@Column
	private Long id_usuario;
	
	private BigDecimal total;

	@JsonIgnore
	@PrimaryKeyJoinColumn(name = "id_pedido")
	@OneToMany(mappedBy = "pedido", targetEntity = DetalhesPedido.class, cascade = CascadeType.ALL)
	private List<DetalhesPedido> detalhesLista = new ArrayList<>();

}
