package com.ibmshop.shoppingapi.feignclients;

import java.math.BigDecimal;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.ibmshop.shoppingapi.dtos.ProdutoDTO;
import com.ibmshop.shoppingapi.entities.Produto;

@Component
@FeignClient(name = "produtos-api", url = "http://localhost:8093", path = "/produtos")
public interface ProdutoFeignClient {

	@GetMapping(value = "/{id}")
	public ProdutoDTO findById(@PathVariable Long id);
	
	/*@PutMapping(value = "/{id}")
	public BigDecimal atualizarEstoque(@PathVariable Long id, @RequestBody BigDecimal estoque);
	*/
	
	@PutMapping(value = "/{id}/estoque")
	public ProdutoDTO atualizarEstoque(@PathVariable Long id, @RequestBody ProdutoDTO produtoDTO);

	@PutMapping(value = "/{id}/ativo")
	public ProdutoDTO atualizarStatusProduto(@PathVariable Long id);
	
}
