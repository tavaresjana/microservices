package com.ibmshop.shoppingapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ibmshop.shoppingapi.entities.Pedido;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {

	@Query(value = "select u from Pedido u where u.status_pedido = ?1")
	Pedido findByStatus(int status_pedido);

}
