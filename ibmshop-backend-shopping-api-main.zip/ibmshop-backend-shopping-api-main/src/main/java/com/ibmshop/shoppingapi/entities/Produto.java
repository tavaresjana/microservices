package com.ibmshop.shoppingapi.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import org.apache.commons.lang.builder.EqualsBuilder;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ibmshop.shoppingapi.dtos.ProdutoDTO;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_produto")
public class Produto implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(nullable = true, unique = false)
	private String nomeProduto;

	@Column(nullable = true, unique = false)
	private String descricao;

	@Column(nullable = false, unique = true)
	private int sku;

	@Column(nullable = true, unique = false)
	private BigDecimal estoque;

	@Column(nullable = true, unique = false)
	private BigDecimal valorUnitario;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "GMT")
	@Column(nullable = true, unique = false)
	private LocalDateTime dataCriacao;

	protected boolean ativo = true;
	
	/*
	 * um produto deve, obrigatoriamente, estar relacionado a uma subcategoria (a
	 * respectiva categoria é carregada a partir dela):
	 */

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "subcategoria_id", referencedColumnName = "id")
	private SubCategoria subCategoria;

	public Produto() {

	}

	public Produto(Long id, int sku, String nomeProduto, String descricao, BigDecimal valorUnitario, BigDecimal estoque,
			SubCategoria subCategoria) {
		super();
		this.id = id;
		this.sku = sku;
		this.nomeProduto = nomeProduto;
		this.descricao = descricao;
		this.valorUnitario = valorUnitario;
		this.estoque = estoque;
		this.ativo = ativo;
		this.subCategoria = subCategoria;
	}

	public Produto(ProdutoDTO objDto) {
		super();
		id = objDto.getId();
		sku = objDto.getSku();
		nomeProduto = objDto.getNomeProduto();
		descricao = objDto.getDescricao();
		valorUnitario = objDto.getValorUnitario();
		estoque = objDto.getEstoque();
		// subCategoria = new SubCategoria(objDto.getSubCategoriaDto());
	}

	public Produto(List<ProdutoDTO> produtoDto) {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getSku() {
		return sku;
	}

	public void setSku(int sku) {
		this.sku = sku;
	}

	public String getNomeProduto() {
		return nomeProduto;
	}

	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public BigDecimal getEstoque() {
		return estoque;
	}

	public void setEstoque(BigDecimal estoque) {
		this.estoque = estoque;
	}

	public BigDecimal getValorUnitario() {
		return valorUnitario;
	}

	public void setValorUnitario(BigDecimal valorUnitario) {
		this.valorUnitario = valorUnitario;
	}

	public LocalDateTime getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(LocalDateTime dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public SubCategoria getSubCategoria() {
		return subCategoria;
	}

	public void setSubCategoria(SubCategoria subCategoria) {
		this.subCategoria = subCategoria;
	}

	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(obj, this);
	}

	@Override
	public String toString() {
		return "Produto [id=" + id + ", nomeProduto=" + nomeProduto + ", descricao=" + descricao + ", sku=" + sku
				+ ", estoque=" + estoque + ", valorUnitario=" + valorUnitario + ", dataCriacao=" + dataCriacao
				+ ", subCategoria=" + subCategoria + "]";
	}

	public boolean isAtivo() {
		return ativo;
	}

	public void setAtivo(boolean ativo) {
		this.ativo = ativo;
	}

	
	
	/*@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Produto other = (Produto) obj;
		return Objects.equals(id, other.id);
	}*/

}
