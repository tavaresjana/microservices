package com.ibmshop.userapi.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ibmshop.userapi.entities.Endereco;

public interface EnderecoRepository extends JpaRepository<Endereco, Long> {
	
	Endereco save(Endereco entity);

	@Query(value = "select u from Endereco u where u.idUser = ?1")
	List<Endereco> findByIdUser(Long idUser);

	@Query(value = "select u from Endereco u where u.apelido like %?1%")
	List<Endereco> findByApelido(String apelido);

}
