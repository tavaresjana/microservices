package com.ibmshop.userapi.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.json.JsonMapper.Builder;
import com.ibmshop.userapi.dto.UsuarioCredentialDTO;
import com.ibmshop.userapi.dto.UsuarioDTO;
import com.ibmshop.userapi.entities.Endereco;
import com.ibmshop.userapi.entities.Usuario;
import com.ibmshop.userapi.feign.UserAuthClient;
import com.ibmshop.userapi.repositories.EnderecoRepository;
import com.ibmshop.userapi.repositories.UsuarioRepository;
import com.ibmshop.userapi.services.exceptions.ObjectNotFoundException;

@Service
public class UsuarioService {

	@Autowired
	private UsuarioRepository usuarioRepository;

	@Autowired
	private EnderecoRepository enderecoRepository;

	@Autowired
	private UserAuthClient userAuthClient;
	
	public List<Usuario> findAll() {
		return usuarioRepository.findAll();
	}

	public Usuario findById(Long id) {
		Optional<Usuario> obj = usuarioRepository.findById(id);

		Usuario usuario = obj.orElseThrow(() -> new ObjectNotFoundException(
				"Desculpe, não foi possível encontrar um usuário com este ID. Verifique e tente novamente."));

		// List<Endereco> enderecoList = new ArrayList <>();

		List<Endereco> enderecoPorIdUser = enderecoRepository.findByIdUser(id);
		// enderecoList.add((Endereco) enderecoPorIdUser);
		usuario.setEnderecosLista(enderecoPorIdUser);

		return usuario;
	}

	public List<Usuario> findByNome(String nome) {
		List<Usuario> obj = usuarioRepository.findByName(nome);
		if (obj.isEmpty()) {
			throw new ObjectNotFoundException(
					"Desculpe, não foi possível encontrar um usuário com este nome. Verifique e tente novamente.");
		}
		obj = usuarioRepository.findByName(nome);
		return obj;
	}

	public List<Usuario> findBylastname(String sobrenome) {
		List<Usuario> obj = usuarioRepository.findByNomeSocial(sobrenome);
		if (obj.isEmpty()) {
			throw new ObjectNotFoundException(
					"Desculpe, não foi possível encontrar um usuário com este sobrenome. Verifique e tente novamente.");
		}
		obj = usuarioRepository.findByNomeSocial(sobrenome);
		return obj;
	}

	public List<Usuario> findByCpf(String cpf) {
		List<Usuario> obj = usuarioRepository.findByCpf(cpf);
		if (obj.isEmpty()) {
			throw new ObjectNotFoundException(
					"Desculpe, não foi possível realizar a busca por CPF. Digite um CPF e tente novamente.");
		}
		return usuarioRepository.findByCpf(cpf);
	}

	public Usuario insert(Usuario obj) {
		obj.setHoraCriacao(obj.getHoraCriacao());
		obj.setActive(true);
		
		userAuthClient.cadastrarUsuario(new UsuarioCredentialDTO(obj.getEmail(), obj.getSenha()));
		
		return usuarioRepository.save(obj);
	}

	public Usuario update(Long id, Usuario obj) {
		Optional<Usuario> entity = usuarioRepository.findById(id);
		updateData(entity, obj);
		return usuarioRepository.save(entity.get());
	}

	private void updateData(Optional<Usuario> entity, Usuario obj) {
		entity.get().setNome(obj.getNome());
		entity.get().setNomeSocial(obj.getNomeSocial());
		entity.get().setTelefone(obj.getTelefone());
		// entity.get().setCPF(obj.getCPF());
		entity.get().setEmail(obj.getEmail());
		entity.get().setSenha(obj.getSenha());
		entity.get().setAdmin(obj.isAdmin());
		entity.get().setHoraModificacao(obj.getHoraModificacao());

	}

	public void delete(Long id) {
		Optional<Usuario> obj = usuarioRepository.findById(id);
		obj.get().setActive(false);
		usuarioRepository.save(obj.get());
	}

	public void reativar(Long id) {
		Optional<Usuario> obj = usuarioRepository.findById(id);
		obj.get().setActive(true);
		usuarioRepository.save(obj.get());
	}

	public Usuario fromDTO(UsuarioDTO objDTO) {
		return new Usuario(objDTO.getId(), objDTO.getNome(), objDTO.getNomeSocial(), objDTO.getDataNascimento(),
				objDTO.getTelefone(), objDTO.getCpf(), objDTO.getEmail(), objDTO.getSenha(), objDTO.isAdmin());
	}

	public List<Usuario> findByEmail(String email) {
		List<Usuario> obj = usuarioRepository.findByEmail(email);
		if (obj.isEmpty()) {
			throw new ObjectNotFoundException(
					"Desculpe, não foi possível encontrar um usuário com este e-mail. Verifique e tente novamente.");
		}
		obj = usuarioRepository.findByEmail(email);
		return obj;
	}

}