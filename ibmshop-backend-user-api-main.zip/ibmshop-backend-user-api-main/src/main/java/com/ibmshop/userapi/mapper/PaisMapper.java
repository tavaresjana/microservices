package com.ibmshop.userapi.mapper;

import org.mapstruct.Mapper;

import com.ibmshop.userapi.dto.PaisDTO;
import com.ibmshop.userapi.entities.Endereco;
import com.ibmshop.userapi.entities.Pais;

@Mapper(componentModel = "spring")
public interface PaisMapper {
	
	Pais DtoParaentidade (PaisDTO paisDto);
	
	PaisDTO EntidadeParaDto (Endereco endereco);
}
