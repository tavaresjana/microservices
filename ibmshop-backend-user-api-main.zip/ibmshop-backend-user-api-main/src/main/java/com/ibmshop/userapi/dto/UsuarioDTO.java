package com.ibmshop.userapi.dto;

import java.io.Serializable;
import java.sql.Date;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.br.CPF;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ibmshop.userapi.entities.Usuario;

import io.micrometer.common.lang.Nullable;
import jakarta.persistence.Column;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class UsuarioDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;

	@NotBlank
	@Length(min = 2, max = 250, message = "Nome do usuário deve ter no minimo 2 caracteres")
	private String nome;

	@Nullable
	private String nomeSocial;

	@NotBlank(message = "O Telefone é obrigatório")
	@Pattern(regexp = "^\\([1-9]{2}\\) (?:[2-8]|9[1-9])[0-9]{3}\\-[0-9]{4}$", message = "Telefone inválido. ((xx) xxxxx-xxxx)")
	private String telefone;

	@NotNull
	@Size(min = 11)
	@CPF(message = "O CPF é obrigatório")
	private String cpf;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "GMT")
	@Column(nullable = false)
	private LocalDateTime horaCriacao;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "GMT")
	@Column(nullable = false)
	private LocalDateTime horaModificacao;

	private boolean isActive = true;

	@NotNull(message = "Informe um e-mail válido.")
	@Email(message = "Um email deve conter caracteres especiais: meuemail@provedoremai.com")
	private String email;
	private String senha;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "GMT")
	@Column(nullable = false)
	private Date dataNascimento;

	private boolean admin = false;

	/*
	 * @JsonProperty("endereco")
	 * 
	 * @Valid EnderecoDTO enderecoDto;
	 */
	private List<EnderecoDTO> enderecosLista = new ArrayList<>();

	public UsuarioDTO() {
	}

	public UsuarioDTO(Usuario obj) {
		id = obj.getId();
		nome = obj.getNome();
		nomeSocial = obj.getNomeSocial();
		dataNascimento = obj.getDataNascimento();
		telefone = obj.getTelefone();
		cpf = obj.getCPF();
		email = obj.getEmail();
		senha = obj.getSenha();
		admin = obj.isAdmin();
		isActive = obj.isActive();
		// enderecoDto = new EnderecoDTO(obj.getEndereco());
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNomeSocial() {
		return nomeSocial;
	}

	public void setNomeSocial(String nomeSocial) {
		this.nomeSocial = nomeSocial;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public LocalDateTime getHoraCriacao() {
		return horaCriacao = LocalDateTime.now();
	}

	public void setHoraCriacao(LocalDateTime horaCriacao) {
		this.horaCriacao = horaCriacao;
	}

	public LocalDateTime getHoraModificacao() {
		return horaModificacao = LocalDateTime.now();
	}

	public void setHoraModificacao(LocalDateTime horaModificacao) {
		this.horaModificacao = horaModificacao;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public boolean isAdmin() {
		return admin;
	}

	public void setAdmin(boolean admin) {
		this.admin = admin;
	}

	public List<EnderecoDTO> getEnderecosLista() {
		return enderecosLista;
	}

	public void setEnderecosLista(List<EnderecoDTO> enderecosLista) {
		this.enderecosLista = enderecosLista;
	}

	public Date getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

}