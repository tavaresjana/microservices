package com.ibmshop.userapi.entities;

import java.io.Serializable;

import com.ibmshop.userapi.dto.PaisDTO;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@EqualsAndHashCode
@Entity
@Table(name = "tb_pais")
public class Pais implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column
	private String nome;

	@Column
	private int codigo;

	public Pais() {

	}

	public Pais(Long id, String nome) {
		this.id = id;
		this.nome = nome;
	}

	public Pais(PaisDTO objDto) {
		nome = objDto.getNome();
		codigo = objDto.getCodigo();
	}

}
