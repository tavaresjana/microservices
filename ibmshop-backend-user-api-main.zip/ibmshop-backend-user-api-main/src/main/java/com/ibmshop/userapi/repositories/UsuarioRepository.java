package com.ibmshop.userapi.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ibmshop.userapi.entities.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

	@Query(value = "select u from Usuario u where u.nome like %?1%")
	List<Usuario> findByName(String nome);
	
	@Query(value = "select u from Usuario u where u.nomeSocial like %?1%")
	List<Usuario> findByNomeSocial(String nomeSocial);

	@Query(value = "select u from Usuario u where u.cpf like %?1%")
	List<Usuario> findByCpf(String cpf);

	Usuario save(Usuario entity);

	@Query(value = "select u from Usuario u where u.email like %?1%")
	List<Usuario> findByEmail(String email);





}
