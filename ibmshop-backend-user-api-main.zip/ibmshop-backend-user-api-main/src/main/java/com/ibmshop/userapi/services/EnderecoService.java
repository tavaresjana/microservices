package com.ibmshop.userapi.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibmshop.userapi.dto.EnderecoDTO;
import com.ibmshop.userapi.entities.Endereco;
import com.ibmshop.userapi.entities.Pais;
import com.ibmshop.userapi.entities.Usuario;
import com.ibmshop.userapi.repositories.EnderecoRepository;
import com.ibmshop.userapi.repositories.PaisRepository;
import com.ibmshop.userapi.repositories.UsuarioRepository;
import com.ibmshop.userapi.services.exceptions.ObjectNotFoundException;

import jakarta.persistence.EntityNotFoundException;
import jakarta.ws.rs.NotFoundException;

@Service
public class EnderecoService {

	@Autowired
	private EnderecoRepository enderecoRepository;

	@Autowired
	private UsuarioRepository usuarioRepository;

	@Autowired
	private PaisRepository paisRepository;

	public List<Endereco> findAll() {
		return enderecoRepository.findAll();
	}

	public Optional<Endereco> findById(Long id) {
		return enderecoRepository.findById(id);
	}

	public Endereco insert(Endereco obj) {

		enderecoRepository.save(obj);

		Optional<Usuario> usuarioOp = usuarioRepository.findById(obj.getIdUsuario());

		if (usuarioOp.get().getId() != null) {
			Usuario usuario = usuarioOp.get();
			List<Endereco> listendereco = new ArrayList<>();
			listendereco.add(obj);
			usuario.setEnderecosLista(listendereco);
			usuarioRepository.save(usuario);
		}
		return obj;
	}

	public Endereco update(Long id, Endereco obj) {
		Optional<Endereco> entity = enderecoRepository.findById(id);
		updateEndereco(entity, obj);
		return enderecoRepository.save(entity.get());
	}

	private void updateEndereco(Optional<Endereco> entidadeEndereco, Endereco obj) {
		entidadeEndereco.get().setIdUsuario(obj.getIdUsuario());
		entidadeEndereco.get().setApelido(obj.getApelido());
		entidadeEndereco.get().setRua(obj.getRua());
		entidadeEndereco.get().setNumero(obj.getNumero());
		entidadeEndereco.get().setCep(obj.getCep());
		entidadeEndereco.get().setComplemento(obj.getComplemento());
		entidadeEndereco.get().setBairro(obj.getBairro());
		entidadeEndereco.get().setCidade(obj.getCidade());
		entidadeEndereco.get().setEstado(obj.getEstado());
		// entidadeEndereco.get().setPais(obj.getPais());
		updatePais(entidadeEndereco.get().getPais(), obj);
	}

	/*
	 * public void updatePais(Optional<Pais> entidadePais, Endereco obj) {
	 * entidadePais.get().setNome(obj.getPais().getNome());
	 * entidadePais.get().setCodigo(obj.getPais().getCodigo()); }
	 */

	public void updatePais(Pais pais, Endereco obj) {
		Pais paisExistente = paisRepository.findById(pais.getId())
				.orElseThrow(() -> new NotFoundException("País não encontrado"));
		paisExistente.setNome(obj.getPais().getNome());
		paisExistente.setCodigo(obj.getPais().getCodigo());
		paisRepository.save(paisExistente);
	}

	/*
	 * se o idUsuario existir, adicione o endereço na lista de endereços do usuario
	 * public Usuario verificaUsuario(Long id) { Optional<Usuario> usuario =
	 * usuarioRepository.findById(id); if(usuario == null) { throw new
	 * RuntimeException("Esse usuário não existe"); } return usuario.get();
	 * 
	 * }
	 */

	public Endereco fromDTO(EnderecoDTO objDTO) {
		return new Endereco(objDTO.getId(), objDTO.getIdUsuario(), objDTO.getApelido(), objDTO.getRua(),
				objDTO.getNumero(), objDTO.getReferencia(), objDTO.getCep(), objDTO.getComplemento(),
				objDTO.getBairro(), objDTO.getCidade(), objDTO.getEstado(), new Pais(objDTO.getPaisDto()));
	}

	public List<Endereco> findByIdUser(Long idUserEndereco) {
		List<Endereco> obj = enderecoRepository.findByIdUser(idUserEndereco);
		if (obj.isEmpty()) {
			throw new EntityNotFoundException(
					"Desculpe, não foi possível encontrar um endereço por esse id de usuário. Verifique e tente novamente.");
		}
		return obj;
	}

	public List<Endereco> findByApelido(String apelido) {
		List<Endereco> obj = enderecoRepository.findByApelido(apelido);
		if (obj.isEmpty()) {
			throw new ObjectNotFoundException(
					"Desculpe, não foi possível encontrar um endereço com este apelido. Verifique e tente novamente.");
		}
		obj = enderecoRepository.findByApelido(apelido);
		return obj;
	}

}
