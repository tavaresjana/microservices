package com.ibmshop.userapi.resources;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.ibmshop.userapi.dto.EnderecoDTO;
import com.ibmshop.userapi.dto.UsuarioDTO;
import com.ibmshop.userapi.entities.Usuario;
import com.ibmshop.userapi.services.UsuarioService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(value = "/usuarios")
@Slf4j
public class UsuarioResource {

	@Autowired
	private UsuarioService usuarioService;

	@GetMapping
	public ResponseEntity<List<UsuarioDTO>> findAll() {
		List<Usuario> list = usuarioService.findAll();
		List<UsuarioDTO> listDto = list.stream().map(x -> new UsuarioDTO(x)).collect(Collectors.toList());
		return ResponseEntity.ok().body(listDto);
	}

	@GetMapping(value = "/{id}")
	public ResponseEntity<UsuarioDTO> findById(@PathVariable Long id) {
		Usuario obj = usuarioService.findById(id);
		UsuarioDTO objDTO = new UsuarioDTO(obj);
		List<EnderecoDTO> listEnderecoDto = obj.getEnderecosLista().stream().map(x -> new EnderecoDTO(x))
				.collect(Collectors.toList());
		objDTO.setEnderecosLista(listEnderecoDto);
		return ResponseEntity.ok().body(objDTO);
	}

	@PostMapping
	public ResponseEntity<Void> insert(@RequestBody @Valid UsuarioDTO objdto) {

		Usuario obj = usuarioService.fromDTO(objdto);
		obj = usuarioService.insert(obj);
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("{id}").buildAndExpand(obj.getId()).toUri();

		UsuarioDTO objDto = new UsuarioDTO(obj);
		return ResponseEntity.created(uri).build();
	}

	@DeleteMapping(value = "/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {

		usuarioService.delete(id);
		return ResponseEntity.noContent().build();
	}

	@PutMapping(value = "/{id}")
	public ResponseEntity<UsuarioDTO> update(@PathVariable Long id, @RequestBody UsuarioDTO objdto) {
		Usuario obj = usuarioService.fromDTO(objdto);
		obj = usuarioService.update(id, obj);
		UsuarioDTO objDTO = new UsuarioDTO(obj);
		return ResponseEntity.ok().body(objDTO);
	}

	@PutMapping(value = "/reativar/{id}")
	public ResponseEntity<Void> reativar(@PathVariable Long id) {
		usuarioService.reativar(id);
		return ResponseEntity.noContent().build();
	}

	@PutMapping(value = "delete/{id}")
	public ResponseEntity<UsuarioDTO> delete(@PathVariable Long id, @RequestBody UsuarioDTO objdto) {
		Usuario obj = usuarioService.fromDTO(objdto);
		obj = usuarioService.update(id, obj);
		UsuarioDTO objDTO = new UsuarioDTO(obj);
		return ResponseEntity.ok().body(objDTO);
	}

	@GetMapping(value = "/nome{nome}")
	public ResponseEntity<List<UsuarioDTO>> findByName(@RequestParam(value = "nome") @PathVariable String nome) {

		List<Usuario> list = usuarioService.findByNome(nome);
		List<UsuarioDTO> listDto = list.stream().map(x -> new UsuarioDTO(x)).collect(Collectors.toList());
		return ResponseEntity.ok().body(listDto);
	}

	@GetMapping(value = "/sobrenome{sobrenome}")
	public ResponseEntity<List<UsuarioDTO>> findBySobrenome(
			@RequestParam(value = "sobrenome") @PathVariable String sobrenome) {
		List<Usuario> list = usuarioService.findBylastname(sobrenome);
		List<UsuarioDTO> listDto = list.stream().map(x -> new UsuarioDTO(x)).collect(Collectors.toList());
		return ResponseEntity.ok().body(listDto);
	}

	@GetMapping(value = "/email{email}")
	public ResponseEntity<List<UsuarioDTO>> findByEmail(@RequestParam(value = "email") @PathVariable String email) {
		List<Usuario> list = usuarioService.findByEmail(email);
		List<UsuarioDTO> listDto = list.stream().map(x -> new UsuarioDTO(x)).collect(Collectors.toList());
		return ResponseEntity.ok().body(listDto);
	}

	@RequestMapping(value = "/cpf{cpf}", method = RequestMethod.GET)
	public ResponseEntity<List<UsuarioDTO>> findByCPF(@RequestParam(value = "cpf") @PathVariable String cpf) {
		List<Usuario> list = usuarioService.findByCpf(cpf);
		List<UsuarioDTO> listDto = list.stream().map(x -> new UsuarioDTO(x)).collect(Collectors.toList());
		return ResponseEntity.ok().body(listDto);
	}

}