package com.ibmshop.userapi.services.exceptions;

public class MissingServletRequestParameterException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public MissingServletRequestParameterException(String message, Throwable cause) {
		super(message, cause);
	}

	public MissingServletRequestParameterException(String message) {
		super(message);
	}
	
	
}
