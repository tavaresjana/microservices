package com.ibmshop.userapi.mapper;

import org.mapstruct.Mapper;

import com.ibmshop.userapi.dto.EnderecoDTO;
import com.ibmshop.userapi.entities.Endereco;

@Mapper(componentModel = "spring")
public interface EnderecoMapper {
	
	Endereco DtoParaEntidade (EnderecoDTO enderecoDto);
	
	EnderecoDTO EntidadeParaDto (Endereco endereco);
}
