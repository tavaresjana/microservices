package com.ibmshop.userapi.resources;

import java.net.URI;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.ibmshop.userapi.dto.EnderecoDTO;
import com.ibmshop.userapi.dto.UsuarioDTO;
import com.ibmshop.userapi.entities.Endereco;
import com.ibmshop.userapi.entities.Usuario;
import com.ibmshop.userapi.services.EnderecoService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(value = "/enderecos")
@Slf4j
public class EnderecoResource {

	
	@Autowired
	private EnderecoService enderecoService;
	
	@GetMapping
	public ResponseEntity<List<EnderecoDTO>> findAll() {
		List<Endereco> list = enderecoService.findAll();
		List<EnderecoDTO> listDto = list.stream().map(x -> new EnderecoDTO(x)).collect(Collectors.toList());
		return ResponseEntity.ok().body(listDto);
	}
	
	@GetMapping(value = "/{id}")
	public ResponseEntity<EnderecoDTO> findById(@PathVariable Long id) {
		Optional<Endereco> obj = enderecoService.findById(id);
		EnderecoDTO objDTO = new EnderecoDTO(obj.get());
		return ResponseEntity.ok().body(objDTO);
	}
	
	@GetMapping(value = "/iduser{idUser}")
	public ResponseEntity<List<EnderecoDTO>> findByIdUser(@RequestParam(value = "idUser", required = true)@PathVariable Long idUser) {
		List<Endereco> obj = enderecoService.findByIdUser(idUser);
		List<EnderecoDTO> objDTO = obj.stream().map(x -> new EnderecoDTO(x)).collect(Collectors.toList());
		return ResponseEntity.ok().body(objDTO);
	}
	
	@GetMapping(value = "/apelido{apelido}")
	public ResponseEntity<List<EnderecoDTO>> findByApelido(@RequestParam(value = "apelido") @PathVariable String apelido) {
		
		List<Endereco> list = enderecoService.findByApelido(apelido);
		List<EnderecoDTO> listDto = list.stream().map(x -> new EnderecoDTO(x)).collect(Collectors.toList());
		return ResponseEntity.ok().body(listDto);
		}	

	@PostMapping
	public ResponseEntity<Void> insert(@RequestBody  EnderecoDTO objdto) {
		
		Endereco obj = enderecoService.fromDTO(objdto);
		obj = enderecoService.insert(obj);
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("{id}").buildAndExpand(obj.getId()).toUri();
		
		EnderecoDTO objDto = new EnderecoDTO(obj);
		return ResponseEntity.created(uri).build();
	} 

	@PutMapping(value = "/{id}")
	public ResponseEntity<EnderecoDTO> update(@PathVariable Long id, @RequestBody EnderecoDTO objdto) {
		Endereco obj = enderecoService.fromDTO(objdto);
		obj = enderecoService.update(id, obj);
		EnderecoDTO objDTO = new EnderecoDTO(obj);
		return ResponseEntity.ok().body(objDTO);
	}
	

}