package com.ibmshop.userapi.entities;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.ibmshop.userapi.dto.EnderecoDTO;

import io.micrometer.common.lang.Nullable;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@ToString
@Entity
@Table(name = "tb_endereco")
public class Endereco implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(nullable = false)
	private String rua;

	@Column(nullable = false)
	private Integer numero;

	@Column(nullable = false)
	private String cep;

	@Column(nullable = false)
	private String complemento;

	@Column(nullable = false)
	private String bairro;

	@Column(nullable = false)
	private String cidade;

	@Column(nullable = false)
	private String estado;

	private boolean padrao;

	private String apelido;

	@Nullable
	private String referencia;

	@Column
	private Long idUser;

	// @JsonIgnore
	@JsonManagedReference
	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "id_usuario")
	Usuario usuario;

	@JoinColumn(name = "id_pais", referencedColumnName = "id")
	@JsonIgnore
	@OneToOne(cascade = CascadeType.PERSIST)
	Pais pais;

	public Endereco() {
	}

	public Endereco(Long id, Long idUser, String apelido, String rua, Integer numero, String referencia, String cep,
			String complemento, String bairro, String cidade, String estado, Pais pais) {
		this.id = id;
		this.idUser = idUser;
		this.apelido = apelido;
		this.rua = rua;
		this.numero = numero;
		this.referencia = referencia;
		this.cep = cep;
		this.complemento = complemento;
		this.bairro = bairro;
		this.cidade = cidade;
		this.estado = estado;
		this.pais = pais;
	}

	public Endereco(EnderecoDTO obj) {
		id = obj.getId();
		idUser = obj.getIdUsuario();
		rua = obj.getRua();
		numero = obj.getNumero();
		referencia = obj.getReferencia();
		cep = obj.getCep();
		complemento = obj.getComplemento();
		bairro = obj.getBairro();
		cidade = obj.getCidade();
		estado = obj.getEstado();
		pais = new Pais(obj.getPaisDto());
	}

	public Long getIdUsuario() {
		return idUser;
	}

	public void setIdUsuario(Long idUser) {
		this.idUser = idUser;
	}

}