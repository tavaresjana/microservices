package com.ibmshop.userapi.entities;

import java.io.Serializable;
import java.sql.Date;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.hibernate.validator.constraints.br.CPF;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.ibmshop.userapi.dto.UsuarioDTO;

import jakarta.annotation.Nullable;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@ToString
@Entity
@Table(name = "tb_usuario")
public class Usuario implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@NotBlank
	@Column
	private String nome;
	
	@Column
	@Nullable
	private String nomeSocial;
	
	@NotBlank
	@Column
	private String telefone;
	
	@NotBlank
	@Column
	@CPF
	private String cpf;
	
	private LocalDateTime horaCriacao;
	private LocalDateTime horaModificacao;
	private boolean isActive = true;
	private String email;
	private String senha;
	private Date dataNascimento;
	private boolean admin = false;

	@JsonBackReference
	@OneToMany(mappedBy = "usuario", cascade = CascadeType.PERSIST)
	private List<Endereco> enderecosLista = new ArrayList<>();

	public Usuario() {
	}

	public Usuario(Long id, String nome, String nomeSocial, Date dataNascimento, String telefone, String cpf,
			String email, String senha, boolean admin) {
		this.id = id;
		this.nome = nome;
		this.nomeSocial = nomeSocial;
		this.dataNascimento = dataNascimento;
		this.telefone = telefone;
		this.cpf = cpf;
		this.email = email;
		this.senha = senha;
		this.admin = admin;
	}

	public Usuario(Long id, String nome, String nomeSocial, Date dataNascimento, String telefone, String cpf,
			String email, String senha, boolean admin, List<Endereco> enderecosLista) {
		this.id = id;
		this.nome = nome;
		this.nomeSocial = nomeSocial;
		this.dataNascimento = dataNascimento;
		this.telefone = telefone;
		this.cpf = cpf;
		this.email = email;
		this.senha = senha;
		this.admin = admin;
		this.enderecosLista = enderecosLista;
	}

	public Usuario(UsuarioDTO objDTO) {
		id = objDTO.getId();
		nome = objDTO.getNome();
		nomeSocial = objDTO.getNomeSocial();
		dataNascimento = objDTO.getDataNascimento();
		telefone = objDTO.getTelefone();
		cpf = objDTO.getCpf();
		email = objDTO.getEmail();
		senha = objDTO.getSenha();
		admin = objDTO.isAdmin();
	}

	public String getCPF() {
		return cpf;
	}

	public void setCPF(String cpf) {
		this.cpf = cpf;
	}

}