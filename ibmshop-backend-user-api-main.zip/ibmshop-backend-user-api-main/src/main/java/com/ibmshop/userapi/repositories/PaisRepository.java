package com.ibmshop.userapi.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ibmshop.userapi.entities.Pais;

public interface PaisRepository extends JpaRepository<Pais, Long>{

}
