package com.ibmshop.userapi.config;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.ibmshop.userapi.entities.Usuario;
import com.ibmshop.userapi.repositories.UsuarioRepository;

@Configuration
@Profile("test")
public class TestConfig implements CommandLineRunner {

	@Autowired
	private UsuarioRepository usuarioRepository;

	@Override
	public void run(String... args) throws Exception {

		/*	Pais pais1 = new Pais(null, "Brasil", 55);
		
		Date date = new LocalDate(1997, 03, 19);
		
		date = new Date();
		 
		Usuario u1 = new Usuario(1L, "Alice Braga", "nome social teste", date, "11931494138","384.883.170-85", "alicebraga@email.com", "12345", false);
		
		Usuario u2 = new Usuario(null, "Maria Bonita", "Silva", "11931494158", "380.985.080-21", (new Endereco(null, "rua antonio cozinheiro", 20, "04843-350", "casa", "Praça da Sé", "São Paulo", "São Paulo")));
		Usuario u3 = new Usuario(null, "Mary Cris", "Krish", "11931494158", "548.467.765-30", (new Endereco(null, "rua joao padeiro", 21, "04843-350", "casa", "Praça da Árvore", "São Paulo", "São Paulo")));

		usuarioRepository.saveAll(Arrays.asList(u1));
		usuarioRepository.saveAll(Arrays.asList(u2));
		usuarioRepository.saveAll(Arrays.asList(u1)); */
	
	}

}