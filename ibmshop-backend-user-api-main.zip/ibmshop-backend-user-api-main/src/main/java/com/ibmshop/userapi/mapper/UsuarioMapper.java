package com.ibmshop.userapi.mapper;

import org.mapstruct.Mapper;

import com.ibmshop.userapi.dto.UsuarioDTO;
import com.ibmshop.userapi.entities.Usuario;

@Mapper(componentModel = "spring")
public interface UsuarioMapper {
	
	Usuario DtoParaEntidade(UsuarioDTO usuarioDto);
	
	UsuarioDTO EntidadeParaDto(Usuario pedido);
}