package com.ibmshop.userapi.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.ibmshop.userapi.entities.Endereco;
import com.ibmshop.userapi.entities.Usuario;

import jakarta.persistence.Column;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class EnderecoDTO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Long id;

	@NotBlank(message="campo rua não pode ser vazio")
	@Size(max = 45)
	private String rua;
	
	//@Size(max = 10)
	private Integer numero;

	@NotBlank
	private String cep;

	@Size(max = 45)
	private String complemento;

	@NotBlank
	private String bairro;

	@NotBlank
	private String cidade;

	@NotBlank
	private String estado;

	private String apelido;
	
	private String referencia;
	
	@Column
	private Long idUser;
	
	@JsonAlias("pais")
	PaisDTO paisDto;

	public EnderecoDTO() {
	}

	public EnderecoDTO(Endereco obj) {
		id = obj.getId();
		idUser = obj.getIdUsuario();
		apelido = obj.getApelido();
		rua = obj.getRua();
		numero = obj.getNumero();
		referencia = obj.getReferencia();
		cep = obj.getCep();
		complemento = obj.getComplemento();
		bairro = obj.getBairro();
		cidade = obj.getCidade();
		estado = obj.getEstado();
		paisDto = new PaisDTO(obj.getPais());
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRua() {
		return rua;
	}

	public void setRua(String rua) {
		this.rua = rua;
	}

	public Integer getNumero() {
		return numero;
	}

	public void setNumero(Integer numero) {
		this.numero = numero;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public PaisDTO getPaisDto() {
		return paisDto;
	}

	public void setPaisDto(PaisDTO paisDto) {
		this.paisDto = paisDto;
	}

	public String getApelido() {
		return apelido;
	}

	public void setApelido(String apelido) {
		this.apelido = apelido;
	}

	public Long getIdUsuario() {
		return idUser;
	}

	public void setIdUsuario(Long idUser) {
		this.idUser = idUser;
	}

	public String getReferencia() {
		return referencia;
	}

	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}

	

	
}